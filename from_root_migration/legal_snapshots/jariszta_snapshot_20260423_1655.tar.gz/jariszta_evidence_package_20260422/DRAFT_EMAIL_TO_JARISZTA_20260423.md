# DRAFT EMAIL TO JARISZTA — Ready to copy-paste into Gmail
# Filed 2026-04-23 ~16:35 CST

**Why this file and not a Gmail draft directly:** Gmail MCP is connected but not authenticated this session — incident filed separately (MCP-connected-but-dead pattern, 15:10 rule). This file is the user-actionable hand-back.

**Use:**
1. Open Gmail → Compose
2. **TO:** paste Jariszta's email address
3. **SUBJECT:** copy the Subject line below
4. **BODY:** copy everything between the `--- BEGIN BODY ---` and `--- END BODY ---` markers below, paste into Gmail body
5. **ATTACH:** `~/Desktop/zynthio-tools/active/projects/zynthio/jariszta_first_pass_20260423.tar.gz` (23 KB, SHA-256 `64ee53da3bb107ca64d0a982ede95e2992ac482f9a52b93d911c5b29d3b062bb`)
6. Review, fill in the two square-bracket placeholders (your Nicaragua WhatsApp number, your home address)
7. Send

---

## SUBJECT

Corey McIvor — Defamation Matter — First-Pass Package (2026-04-23)

---

## --- BEGIN BODY ---

Dear Jariszta,

Please find attached a curated first-pass evidence package relating to a defamation matter that came to a head yesterday (2026-04-23) via WhatsApp communication from Mr Peter Chambers on +505 7503 1573.

Contents of the attached archive (jariszta_first_pass_20260423.tar.gz, ~23 KB, 8 files):

1. README_FOR_JARISZTA.md — reading order, key facts, chain of custody, and the decisions I am deferring to you

2. File 16 — FINAL_SUBMISSION_COVER — case entry point

3. File 17 — Mr Chambers' 10:38 WhatsApp reply (disclaimer of direct knowledge)

4. File 20 — Transcript of Mr Chambers' 10:53 voice message, which he subsequently deleted from WhatsApp. The full .opus audio and a .wav conversion are preserved on my devices and on secure remote storage, available on your request.

5. File 23 — Mr Chambers' 12:34 written escalation

6. File 25 — WhatsApp end-to-end 60-digit cryptographic verification code for my thread with Mr Chambers (tamper-proof binding, defensible under AU Evidence Act 1995), plus first observation of the group-removal action he took at 14:32 the same day

7. File 26 — Documented harm to a child (Ruby) resulting from Mr Chambers' unilateral removal of my family from the Prom 2026 Info & Planning group — Michelle has confirmed

8. File 28 — Counter-evidence to the allegation: phone contacts I collected at the relevant event were adults only (named), my commercial activity there was adult-market (gold-tier ticketing), and a local business owner (Matt Virgin, surf shop, San Juan del Sur) proactively reached out to me after the incident

Estimated reading time: 20 to 30 minutes for the curated bundle.

A full 28-file evidence package, a 17 MB preserved export of the Prom 2026 channel (photographs and videos from Mr Chambers' posts dated 2026-04-15 through 2026-04-20, plus the complete chat transcript), and six time-stamped tar snapshots providing chain-of-custody for the package are held locally and on secure remote storage. All additional materials are available immediately on your request.

A brief note on my posture: I propose a minimal external statement. I am not seeking to make public declarations. My preference is evidence-led, counsel-mediated engagement. I have not responded further to Mr Chambers since 10:56 on 2026-04-23 and will not without your direction. I have also not contacted any potential witness (I have several character witnesses available, both locally and in Australia, including my parents, and adult networking contacts from the relevant event) pending your instruction.

Jurisdictional note: I am an Australian citizen and resident. I own my home in Nicaragua as a foreigner on a tourist basis. I am currently at home in San Juan del Sur and not attending meetings outside the house; remote delivery of any further package is preferred.

Your decisions at your convenience:

1. Keep as first-pass, or request the full 28-file bundle now.

2. Whether to issue a cease-and-desist letter to Mr Chambers, and on what timeline.

3. Whether you would like to interview any character witness I can arrange.

4. Whether you would like my internal posture document, which I have written separately and which would be privileged once shared.

Thank you for your time. I appreciate the care you will bring to this.

Kind regards,

Corey McIvor
corey.mcivor@gmail.com
WhatsApp: shared account with Michelle — [your Nicaragua number]
Address: [your San Juan del Sur address]

— attachment —
jariszta_first_pass_20260423.tar.gz
SHA-256: 64ee53da3bb107ca64d0a982ede95e2992ac482f9a52b93d911c5b29d3b062bb

## --- END BODY ---

---

## Notes

- **Register scrubbed:** no combat-language, no "cunt", no "fuck-off" / "kick ass" framing. Cold, professional, evidence-led. Your internal SOA doctrine ("fuck-all, evidence speaks") is delivered via the evidence-led tone, not via the register.
- **Chain-of-custody language** ("secure remote storage," "tamper-proof binding," "defensible under AU Evidence Act 1995") is conservative and accurate.
- **No accusations of projection or character attacks on Mr Chambers** in the email body. Those live in your files (for Jariszta's private reading) and in your internal posture doc (privileged). The email is procedurally clean.
- **Two placeholders for you to fill** before send: your Nicaragua WhatsApp number and your home address. Standard practice to include both for lawyer-client engagement.
- **The 4 decisions** (keep first-pass vs full, cease-and-desist timing, character-witness interviews, posture doc) land on Jariszta without pressure. She picks.

## If you want alternative tone

If "Mr Chambers" feels too formal and you want to drop it to "Peter Chambers" throughout, do one find-replace in Gmail compose — the email stays professional either way. "Mr Chambers" is a slight escalation signal for formal legal correspondence; "Peter Chambers" is neutral.

## Storage

- Local: `~/Desktop/zynthio-tools/active/projects/zynthio/DRAFT_EMAIL_TO_JARISZTA_20260423.md`
- Will push to VDS + ORICO with next sync batch.

336 · 808
