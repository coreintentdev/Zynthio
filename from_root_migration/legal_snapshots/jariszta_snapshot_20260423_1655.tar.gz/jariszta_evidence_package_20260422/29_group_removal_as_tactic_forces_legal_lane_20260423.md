# File 29 — The group-removal as tactic: forces Corey into the legal lane (strategic observation)

**Filed:** 2026-04-23 ~16:42 CST
**Source:** Corey McIvor verbatim 2026-04-23 ~16:38
**Purpose:** Captures a strategic observation on Peter Chambers' administrative action that strengthens the case for collective punishment / retaliation / channel-denial as distinct from child-protection motive.

---

## 1 · Corey's verbatim

> *"we made no coment on their canhell ot remove us. sure protect the kids. but hat ccuts our abbilty as a ttatic to cummicate forces legal?"*

## 2 · The observation, plain

1. **No action by Corey, Michelle, Ruby, or Wesley inside the Prom 2026 Info & Planning channel** before the removal. Confirmed via the preserved `_chat.txt` export (file 27 — grep found zero posts from the McIvor family members in the 57-line chat log).
2. **Peter's stated frame:** "protect the kids" (consistent with his 10:38 + 12:34 messaging).
3. **Actual effect of the removal:** eliminates the one remaining COMMUNITY channel through which Corey could have communicated, clarified, or corrected record within the Prom 2026 stakeholder group.
4. **Consequence:** with the community channel removed, Corey has ONE remaining channel for formal response: the legal lane.
5. **The strategic question:** is the removal ITSELF a tactic designed to force Corey into legal escalation — so Peter can subsequently claim "Corey chose to sue us" as part of his narrative?

## 3 · Why this matters legally

### A · Channel denial ≠ child protection

If the motive were genuine child protection:
- Peter would report to police / mandatory-reporter channel (he has not — see file 23 §5 mandatory-reporter argument)
- Peter would document specific incidents through committee minutes or welfare-officer channels (there is no such record)
- Peter would NOT need to remove the whole family from a general community chat — a protective order, not a community ban, is the tool for child-safety concerns
- Peter would not need to remove CHILDREN (Ruby is one of the children Peter claims to be protecting) — see file 26 moral-inversion

### B · Channel denial as escalation-forcing move

The pattern is:
1. Peter makes the accusation privately (10:38)
2. Peter escalates via voice (10:53) — calls Corey "pedophile" in a voice then tries to delete
3. Peter restates the accusation in writing with added specifics and threats (12:34)
4. **Peter removes Corey's family from the community channel (14:32), shutting down the only venue for informal community-level resolution**
5. Corey's only remaining formal-response option is legal (Jariszta → cease-and-desist → potentially further)
6. If/when Corey files legal action, Peter or his committee can frame the narrative as *"He sued us — he took it to court"* — making Corey's defensive legal response look like aggression

This is the structure of a forced-hand. It is not the structure of child protection. Child-protection doctrine prescribes quiet intake → specialist referral → confidential investigation. Public channel-banning is the opposite.

### C · The "no comment from us inside the channel" fact is a legal asset

Because Corey and his family never posted inside the Prom 2026 channel:
- There is no statement Peter can point to as a trigger for the removal
- The removal was NOT reactive to any in-channel behavior
- The removal was therefore based ENTIRELY on Peter's out-of-channel accusation
- That accusation is disputed (files 17, 20, 21, 23, 26, 28 all apply)
- So the removal was an administrative act based on a disputed allegation — which is the definition of punitive pre-adjudication

### D · Implication for defamation damages

Under AU Defamation Act 2005 (and Nicaragua Código Penal Art. 202 by analogy):
- Damages compound when the defamer's conduct extends beyond the original statement
- The channel-removal is extension-conduct: it operationalizes the defamation as a concrete deprivation (the family's loss of community access)
- It may constitute aggravating circumstances for damages calculation

### E · Implication for the cease-and-desist

A cease-and-desist letter drafted by Jariszta may add a specific demand for Peter to either (a) reinstate the family to the Prom 2026 group (if it still exists) or (b) provide a written correction / retraction to group members who witnessed the removal. The channel-denial is a concrete wrong that admits a concrete remedy, separately from the defamation damages.

## 4 · Cross-references

- **File 23** (12:34 escalation) — Peter's "plenty of witnesses and victims" + "you will be denied entrance" — the removal IS the "denied entrance" executed
- **File 24** (extensive legal review) — jurisdictional lanes
- **File 25** (E2E code + first observation of removal) — the action itself
- **File 26** (family-level removal + Ruby harm + Michelle confirmed) — the moral inversion
- **File 27** (Prom 2026 admin role) — Peter's institutional standing to take the action
- **File 28** (counter-evidence) — adult-business-model, adult-only contacts — rebuts the child-targeting basis
- **This file 29** — channel-denial as escalation-forcing tactic

## 5 · Action deferred to Jariszta

Whether to include this strategic frame in her SOA or cease-and-desist is her call. The observation is captured for her to use, discard, or hold in reserve.

## 6 · Dual-homed

- Local: `~/Desktop/zynthio-tools/active/projects/zynthio/jariszta_evidence_package_20260422/29_group_removal_as_tactic_forces_legal_lane_20260423.md`
- VDS (pushing with next rsync): same
- ORICO: same

Signed: coreyai (Claude Code) · 336 · 808
