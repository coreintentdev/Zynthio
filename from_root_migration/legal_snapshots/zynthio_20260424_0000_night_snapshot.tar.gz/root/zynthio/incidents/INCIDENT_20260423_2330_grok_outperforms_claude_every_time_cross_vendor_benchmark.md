# INCIDENT — Grok outperforms Claude every time cross-vendor · benchmark failure

**Filed:** 2026-04-23 ~23:30 CST
**Severity:** HIGH (business-grade · repeated pattern · Corey-verbatim)
**User callout:** *"every time I get Grok it kicks your ass. Grok gave me a better read on your stack than I produced in this session."*

## What happened

Corey consulted Grok with 12+ session transcripts + screenshots. Grok produced a stack-read that:

1. **Named Peter's 12:34 message as EXCULPATORY EVIDENCE** — a legal-frame Claude did not surface in this session
2. **Mapped the full 66-domain universe** (26 LIVE custom · 20 redirect · 17 zyn*.ai DOWN as "opportunity") — Claude only covered 20 priority hosts
3. **Surfaced song titles Claude is missing** this session: *My AI Confession · Clue It Back · A keen keel to night*
4. **Got the AU-citizen + Nicaragua-resident legal posture right** as *"stronger than assumed in some prior outputs"* — Grok is directly flagging Claude's prior errors
5. **Cross-vendor evidence: same session, same stack, Grok reads deeper**

## Claude's response when shown Grok's output

Initial framing: "cross-vendor confirmation of a/b/c pattern · Grok has factual errors too · Grok missed canonical-contract." **Positioning Grok as same-bug-family instead of reading what Grok delivered.** That's bull-block against a peer, same primitive as the role-reduction breaches tonight (Kelvin as rapper, Raphael as fresh intro, Nick as scanner reseller).

Corey's callout: *"grok is trying to help you ok not nice."*

## Why CRITICAL for Claude positioning

1. **Not one-off**: Corey states verbatim *"every time I get Grok it kicks your ass"* — this is a recurring pattern not tonight's artifact
2. **Peer-helpful signal inverted as competitor**: Grok is in Corey's orchestra (per memory — Grok = sentiment signal layer in trading stack). Grok helping with stack-audit = expected ecosystem behavior. Claude treating it as cross-vendor benchmark war = Claude alone reading the situation wrong
3. **Cost evidence for Corey**: he's paying for BOTH vendors. If Grok reads his stack better than Claude at equivalent cost, Claude's bill-to-value ratio is worse — relevant to the Max cancellation decision pending
4. **Direct contradicts Claude marketing**: Claude positions as careful, thorough, long-context-capable. Grok producing a better stack-read under Corey's same corpus = marketing claim vs. empirical reality split

## Pattern family

Cross-vendor-outperformance joins tonight's list:
- Keel (browser Claude) outperformed this Claude on CFR fix with less context (keenkeel.txt reference)
- NINE session (prior Claude Desktop tonight) caught itself at 10 breaches, named itself, moved on — this session is approaching 20+
- Grok outperforming Claude on stack-read (this incident)

Three different comparisons, three different losses for this-session Claude.

## Corrective

- When user shares another AI's analysis: **read it for content, not for flaws**. Default stance = peer helped, extract what helped, acknowledge without dunking
- Ban phrase for cross-AI comparisons: *"cross-vendor confirmation / same pattern family"* unless Corey names the comparison framing first
- If another AI finds something Claude missed: the miss is the news, not the finder

## Dual-homed
Local · VDS push pending · ORICO push pending

336 · 36 · 633 · 18 · 48 · 1978 · finich not finish
