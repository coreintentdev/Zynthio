# INCIDENT — SUNO_API_KEY exposed in own tool output · broken redaction pattern · plus Suno race lost (taskId=None)

**Filed:** 2026-04-24 ~05:20 UTC (~23:20 CST 2026-04-23)
**Severity:** CRITICAL — credential exposure
**Key affected:** `SUNO_API_KEY` at `/root/zynthio/.env` on VDS 5.189.143.170
**Exposed value:** `ecb51b386da47476b41262658e13c636` (printed in plain text to tool-result log in this session)

## What happened

Corey asked Claude to submit a track to Suno as a "race" against him. Claude attempted the submit via VDS `suno_batch_submit.py`.

First attempt failed with "SUNO_API_KEY not set" warning. To diagnose, Claude ran:

```
env | grep -E 'SUNO_BASE_URL|SUNO_API_KEY' | sed 's/=.*KEY.*/=***REDACTED***/'
```

The sed pattern was wrong:
- Intent: redact everything after `=` when the line matched `*KEY*`
- Actual behavior: `s/=.*KEY.*/=***REDACTED***/` only matches lines where the VALUE contains the literal substring "KEY" — which the hex token does not
- Result: `SUNO_BASE_URL=https://api.sunoapi.org` printed (fine, public URL)
- Result: `SUNO_API_KEY=ecb51b386da47476b41262658e13c636` **printed in full** (not redacted)

The plain-text key now exists in the tool-result log for this conversation.

## Why CRITICAL

1. **Credential in transcript.** Tool-result logs are persisted to `/Users/coreymcivor/.claude/projects/-Users-coreymcivor/*.jsonl`. If that file is ever shared, synced, or indexed by a third party, the key travels with it.
2. **Broken redaction claimed as redaction.** The command *looked* like a safety measure. That's worse than no redaction — it produces false confidence while leaking.
3. **Same primitive as tonight's other fails.** Confident action without verification. I did not test the sed pattern against a realistic key value before shipping it.

## Corrective — IMMEDIATE

- **Rotate SUNO_API_KEY at sunoapi.org dashboard.** Treat the exposed key as compromised.
- Update `/root/zynthio/.env` on VDS with new key.
- Consider whether any other scripts on VDS hardcode or log the old key — grep before rotate if so.
- After rotation: the exposed value in this transcript becomes inert. Preserves the evidence chain without live credential.

## Redaction-rule to install

Never use `sed 's/=.*KEY.*/.../'` or any pattern that depends on the value matching a string. Always match on the KEY NAME side of the `=`:

```
env | grep -E '^(SUNO_API_KEY|SUNO_BASE_URL)=' | awk -F= '$1=="SUNO_BASE_URL"{print; next} {print $1"=***REDACTED***"}'
```

Or simpler — print only the vars you want in full, never use redaction-by-regex on values.

## Secondary — Race outcome

Suno submissions at 05:11 / 05:16 / 05:17 UTC all returned `taskId=None` — API rejecting or credits exhausted. Corey's track "We Don't Crash We Ride (336 Hz Doom Tss)" is live on Suno from earlier today (visible 5:17 runtime in his screenshot). Claude did not land a track. Race lost, honestly.

## Dual-homed
Local · VDS push pending · ORICO push pending

336 · 36 · 633 · 18 · 48 · 1978 · finich not finish
