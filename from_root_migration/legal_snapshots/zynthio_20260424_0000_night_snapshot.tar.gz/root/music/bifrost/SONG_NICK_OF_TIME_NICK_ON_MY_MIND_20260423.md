---
title: "Nick of Time (Nick on My Mind)"
slug: nick-of-time-nick-on-my-mind-20260423
artist: coreymcivor
style: "mid-tempo dark electro rock with HARD CORE SIN CRASH register, 124 BPM, 336 Hz drone bed, distorted verse guitar + electronic chorus, half-time bridge with 808 floor, male vocal measured then released, dry and dirty mix — companion to Nick the Bull + SONG_PACK_NICK_THE_BULL_CHATGPT_5TRACKS_20260422"
ai_generated: true
originality_risk: low_medium
distrokid_eligible: pending_similarity_check
suno_public: optional — user's call
bifrost_vault: true
source: "Corey 2026-04-23 ~23:45 — direct ask: 'song nick of time with nick on my mind'. Wordplay: Bonnie Raitt 'Nick of Time' (1989) + Nick El Dorado the DIRECTION MANAGER / 3D scanner owner in Ottawa. Nick-of-time = just-in-time. Nick-on-my-mind = the scanner pitch Corey is carrying."
note: "Private-matter scrub applied: no divorce-line in lyric (same rule as Nick WhatsApp draft). Scanner = Artec Leo confirmed. Five angles landed today. Companion to AI-That-Reads-First + We-Don't-Crash-We-Ride + If-I-Said-Yes-That-Would-Be-Mean. No direct send to Nick — Bifrost vault only."
---

# Nick of Time (Nick on My Mind)

## [INTRO — spoken, dry, 336 Hz drone]
Five months out · come today
Scanner sitting · Ottawa in the cold
Direction Manager holds the line
Nick of time · Nick on my mind

## [VERSE 1]
Artec Leo in a box in the northern light
Battery charger · two new ones · receipt on sight
Five months of "soon" · now it's tonight
The pitch is on disk · the angles are tight

Gabriel at Ocean Dental · scan for the crown
Ricardo at Constructora · as-built going down
Natalie at SJDS · virtual tours for the town
Forty-eight domains wider · if the first three don't sound

## [PRE-CHORUS]
Five months out · come today
The word is the wager · the wager is the way
Twenty jobs to ROI · we know the math
Nick of time · finds the path

## [CHORUS]
Nick of time · Nick on my mind
Scanner moves · the cash arrives
Five real angles · three direct · two in the wide
Nick of time · Nick on my mind

Nick of time · find the line
Direction Manager · holds the sign
Corey rides · Nick decides
Nick of time · Nick on my mind

## [VERSE 2]
Rental pool if the outright stalls
Keep the name · keep the walls
One-fifty to three · monthly from the calls
Nick holds ownership · the system halls

Bull that listens to the lead · not to the red
Charge-at-the-signal · not at the thread
Corey reads before he writes · that's the edge
Nick reads the offer · Nick nods at the ledge

## [PRE-CHORUS]
Five months out · come today
Direction Manager · don't let it fray
Scanner sings for the dental chair
Scanner sings for the construction square
Scanner sings for the real estate there
Nick of time · fill the air

## [CHORUS]
Nick of time · Nick on my mind
Five angles tight · all aligned
Dental · construction · real estate defined
Nick of time · Nick on my mind

Nick of time · the keel in the cold
Nick of time · the direction foretold
Nick of time · the stack unfolds
Nick of time · the Bull gets gold

## [BRIDGE — half-time, 808 drops, Michelle + Corey shared-WhatsApp ghosted in back]
Ottawa winter · San Juan sun
The scanner moves from the one to the one
Direction Manager from frozen north
To the coast that sells the worth

Pete in Perth with the jet-boat keel
Brother knows the boat but not the deal
Nick knows the machine · Corey knows the reel
Nick of time · the art of what's real

Three riders on the coast · one ship in the ice
The keel is the pitch · the pitch is the price
The price is the floor · the floor is the rise
Nick of time · Corey's eyes

## [VERSE 3]
WhatsApp thread · 4:51pm
Artec Leo video · link sent in
Original receipt · "all good thanks"
Direction Manager moves · Corey's side ranks

CoreyAI's POD: read before you write
Grep before you guess · stay in the light
Nick's contract already drafted · on the drive
Nick of time · don't fabricate · arrive

## [FINAL CHORUS]
Nick of time · Nick on my mind
Five angles · three direct · two combined
Forty-eight-domain wider · if the need's refined
Nick of time · Nick on my mind

Nick of time · the keel holds true
Nick of time · the red not blue
Nick of time · the Bull comes through
Nick of time · Corey sees you

## [OUTRO — spoken, drone sustains]
Artec Leo · received.
Receipt · received.
Battery · charger · received.
Two new batteries · received.
Five angles · ready.
Buyer intros · tomorrow morning.
Dental · construction · real estate · network · rental.
Nick · of · time.
Nick · on · my · mind.

336 · 33¢ · 36 · 633 · 808 · 18 · 48 · 1978
HARD CORE SIN CRASH · San Juan del Sur · Ottawa cold
Nick of time · Nick on my mind
finich not finish

coreyai · Corey James McIvor
