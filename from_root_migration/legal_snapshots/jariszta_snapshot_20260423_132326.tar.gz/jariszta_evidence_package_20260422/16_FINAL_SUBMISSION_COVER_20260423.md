# 16 · FINAL SUBMISSION COVER — for Jariszta

**Date:** 2026-04-23
**From:** Corey McIvor
**For:** Jariszta (named counsel)
**Status:** Package complete. Today's update folded in as file 17. This cover replaces the informal README as the entry point for the meeting today.

---

## One-paragraph statement of the matter

On 2026-04-19, on the sidewalk outside **Bottoms Up** bar, San Juan del Sur, following the public "Prom 2026 Carnival Fundraiser" (1–4 pm, event broadcast attached in file 14), I was publicly accused and verbally threatened in front of my wife and children. My daughter Ruby heard the slur *"pedophile"* said as the family left. Michelle filmed the departure. I did not engage physical confrontation — I left. The package in this folder preserves that record. On 2026-04-23 the matter has escalated in writing: the event organiser Peter Chambers, after I wrote to him about the 2026-04-19 defamation, replied introducing a **new unsourced allegation** about "a patron at the event asking students for their numbers and acting inappropriately" — full reply and analysis in file 17.

## What I am asking you to do

I am not asking you to pursue or attack anyone. My posture (stated 2026-04-22 and unchanged today):

> *"I don't want to take anyone down. I help people. I tell Jariszta she helps or not or just takes note. I don't need her help. Give her full context. I am not going to take out the instigator or the bully the way you think."*

Three options. Please pick one today or as soon as you're able:

1. **NOTE** — read the package, no action, keep on file in case it escalates further.
2. **ADVISE** — tell me what I should and should not say / do next (particularly re: Peter's 2026-04-23 reply introducing the second allegation).
3. **ACT** — formalise protective correspondence to the parties named in files 06 + 07 + 17, or engage Nicaragua-local counsel via your referral network.

Whichever you pick, I accept. Helper-first is the posture — yours and mine.

## What I am NOT asking for

- I am not pursuing the instigator / the bully / the blonde girl named in file 06.
- I am not pursuing the school community broadly.
- I am not filing a criminal complaint in Nicaragua unless you advise otherwise.
- I am not dragging Michelle or the kids into anything public.

## The three priorities that drive this

1. **Protecting Ruby's future access** to school and community events — she heard a slur about her dad that she should not have heard, and cannot be exposed to the crowd that said it again.
2. **Evidence preservation** — documentary record in case one of the other parties escalates. Package is intentionally complete so I never have to re-reconstruct it.
3. **Written-only contact channel from here** — any further engagement with Peter Chambers or the 2026-04-19 parties goes lawyer → lawyer or not at all. (File 05 is the template; not sent yet.)

## Key facts in one block

| Field | Value |
|---|---|
| Incident date | 2026-04-19, approx. 4 pm end of the fundraiser |
| Location | sidewalk outside Bottoms Up, San Juan del Sur |
| Venue owner | Kate (file 07) — personally invited Corey earlier |
| Witnesses present | Michelle (wife, filmed departure), Ruby (daughter, minor, heard slur), Wesley (son), ~20 "red-shirt pro-school" bystanders |
| Slur aired publicly | "pedophile" (file 01 §3) — heard by Ruby |
| Direct threat | "I will kick your fucking ass" (file 01 §4) |
| Car-bonnet incident | someone jumped on Corey's car (file 01 §3) |
| De-escalation outcome | both men left; Corey disengaged, family left filmed (file 01 §5–6) |
| Second event 2026-04-23 | Peter Chambers WhatsApp reply introducing "patron/students/inappropriate" framing (file 17) |
| Legal precedent in Corey's history | all prior charges WIPED by judge, cleared by Benjamin Bullock (ref `user_legal_history_charges_wiped_ben_bullock.md`) — NEVER reference Corey as having a record |

## How to read the folder (suggested)

1. **This file (16)** — what you're reading
2. **File 17** — today's Peter Chambers escalation (READ SECOND — it's the hot material)
3. **File 01** — primary 2026-04-19 narrative
4. **File 06** — identity anchors (who is who)
5. **File 14** — independent third-party event broadcast (proves the fundraiser + timing)
6. **File 07** — Kate / Bottoms Up owner background
7. **File 03** — evidence-pack summary
8. **File 05** — prior draft legal notice (not sent)
9. **File 02 EN + ES** — school/community letter drafts (principal-ready, not sent)
10. **Files 10 + 11** — AI fabrication incidents (transparency: some drafts in this corpus were AI-generated; these two files document where AI got it wrong so you can audit provenance)

## Transparency — AI provenance

Package compiled with Claude (Anthropic API), Grok (xAI), Gemini (Google), Perplexity. Files 10 + 11 log specific AI fabrications Corey caught and corrected. Any remaining AI-fabricated detail in this package is Corey's to flag when you raise it. Nothing in this package is submitted as fact where it is AI-inferred — everything factual is either Corey's verbatim account or independent evidence (Michelle's video, WhatsApp broadcast, etc.).

## What's NOT in this folder (Corey provides in person)

- Photos from the 2026-04-19 event (on Corey's phone)
- Michelle's departure video (file 04 references it; file on Corey's phone)
- Michelle's direct verbal account (she's the primary adult witness outside the family)
- Full WhatsApp corpus (52,261 lines; file 14 is the event-broadcast extract; full export available on request)

## Contact

**Corey McIvor**
Email: corey.mcivor@gmail.com (primary) · corey@coreyai.ai (business)
WhatsApp (shared with Michelle): on file with you
NZ-registered business: ZYNTHIO LIMITED #15436626 (NZ) — Corey is based in Nicaragua, business in NZ

Michelle Grogan (wife, co-witness) — contact on request.

---

**Package complete as of 2026-04-23 ~10:50 CST.** Today's addendum (file 17) was added AFTER Peter Chambers' 10:38 WhatsApp reply. I have not responded further on that thread since you and I are meeting today.

virtually, digitally yours —
coreyai
