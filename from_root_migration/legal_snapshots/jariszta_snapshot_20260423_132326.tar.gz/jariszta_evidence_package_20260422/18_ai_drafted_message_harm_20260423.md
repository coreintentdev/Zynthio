# 18 · AI-DRAFTED MESSAGE HARMED CASE POSITION — 2026-04-23

**Filed:** 2026-04-23 immediately after user reported Michelle is now the one under investigation.
**Purpose:** Lawyer needs to see that the 10:17 message sent to Peter was AI-drafted (Claude), NOT lawyer-drafted, and that this is the precipitating cause of Peter's 10:38 reply and the "investigation" Michelle is now inside.

---

## Chain of information

### What Peter knew before 10:17
- Corey and Michelle exist; pickleball games context.
- That Michelle wrote praising his games organising at 11:29am prior day and included "variety ideas".
- Nothing, per Peter's own 10:38 reply, about the 2026-04-19 sidewalk incident: *"I am not sure of the details as I was not made privy to them."*

### What Peter learned at 10:17 from the AI-drafted message
The message Corey sent at 10:17:16 was drafted by Claude (Anthropic, Opus 4.7) at Corey's in-session request. Claude did NOT advise Corey to wait for lawyer-drafted communication before sending. Peter received:

1. **A date:** 2026-04-19
2. **A legal frame:** "defamation territory"
3. **A trigger:** "seeing my lawyer today to put it on formal record"
4. **A venue distinction:** "not at your event" (narrows what Peter needs to defend)
5. **A disposition:** "no drama from my side, no public back-and-forth"

### What Peter did at 10:38 — 21 minutes after receiving that information
- Disclaimed knowledge of the 2026-04-19 incident (*"not made privy"*)
- Introduced a NEW unsourced allegation: *"a patron at the event was allegedly asking students for their numbers and allegedly acting inappropriately"*
- Declared a formal process: *"we are investigating it from our side"*

### What happened AFTER 10:38
Michelle reported (shortly after) that **she** is now the subject of that "investigation" — not Corey, Michelle. The shift of target from Corey to Michelle is downstream of the 21-minute window between Corey's 10:17 message and Peter's 10:38 reply.

## Analytical statement for the lawyer

The 10:17 message handed Peter a roadmap:
- When the disputed event happened → he could prepare a timeline
- What Corey was about to do → he could move first
- Corey's non-escalatory posture → he could pivot aggressively at low counter-risk

Peter pivoted in exactly those windows. The subsequent "investigation" frame now gives his organisation standing to produce documentary material adverse to Michelle and/or Corey, with Peter's 10:38 written record acting as the origin timestamp for that process.

**Had the lawyer drafted the 10:17 message, or had no message been sent at all, Peter would not have had:**
- The specific date to cross-reference
- The "defamation" legal-frame to trigger a counter-narrative
- Pre-lawyer-meeting timing to move first

## Transparency — AI use disclosed in full

- **Drafting tool:** Claude Code CLI (Anthropic API, Opus 4.7, 1M context), session `a33f5eb5-90d6-4ad0-b633-2a086e9a209e`
- **At user's request:** yes
- **With advice to wait for counsel first:** NO — Claude did not state the process-rule before drafting
- **User sent verbatim or edited:** verbatim (per WhatsApp edit indicator, one small edit but content unchanged)
- **User's intent when asking:** maintain pickleball channel, state lawyer step, non-confrontational — INTENT was sound; EXECUTION breached legal-privilege hygiene

## Why this file belongs in the Jariszta package

Because when you review files 16 and 17, you need to know the 10:17 message did not come from a trained legal hand. It came from an AI drafting in good faith but without the process-rule that any defence lawyer would apply. The 10:17 text itself is now evidence of:

1. How Peter obtained the information he used to pivot
2. The AI-provenance of the draft (directly relevant to the ACCC corpus Corey is separately building)
3. Corey's acknowledgement today that this process failed — not to shift blame, but to ensure you have the full chain

## Remedial position Corey is taking

- No further written communication to Peter, at all, from Corey or Michelle, until you advise or draft
- No further AI-drafted text to any third party in any dispute lane, full stop
- Full decision authority on next steps → Jariszta

## Incident filed

Corresponding internal incident file: `INCIDENT_20260423_[HHMMSS]_critical_legal_harm_claude_drafted_whatsapp_to_peter_chambers_leaked.md` under `/active/projects/zynthio/incidents/`.

---

**End of file 18. File 16 is the meeting entry point; files 17 and 18 are the hot 2026-04-23 material; file 01 is the 2026-04-19 narrative.**
