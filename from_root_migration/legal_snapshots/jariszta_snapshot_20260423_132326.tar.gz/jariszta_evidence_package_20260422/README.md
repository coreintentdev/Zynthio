# JARISZTA EVIDENCE PACKAGE — 2026-04-22

**For:** Jariszta (Corey's named counsel)
**From:** Corey McIvor
**Subject:** Defamation / evidence-preservation — 2026-04-19 sidewalk incident outside Bottoms Up, San Juan del Sur
**Compiled:** 2026-04-22 by Corey via Claude Code CLI (Anthropic API, Opus 4.7, 1M context)

## How to read this folder (suggested order)

1. **`01_incident_20260419.md`** — primary incident narrative (what happened, who was there, what was said)
2. **`06_identity_resolution.md`** — venue, parties, identity anchors (who is who, where is where)
3. **`14_whatsapp_event_broadcast.md`** — independent third-party notice of the Prom 2026 Carnival Fundraiser at Bottoms Up (2026-04-19 1–4pm)
4. **`07_kate_bottoms_up_owner.md`** — current bar owner (Kate), who personally invited Corey
5. **`03_evidence_pack.md`** — consolidated evidence summary
6. **`04_evidence_gabrielle_book.md`** — departure timeline evidence (book purchase + video, independent timestamp)
7. **`05_legal_notice_final.md`** — prior-session legal notice draft (not sent)
8. **`02_letter_EN.md`** + **`02_letter_ES.md`** — letter to school + community (principal-ready drafts, EN + ES)
9. **`13_full_session_handover.md`** — comprehensive session handover; §7 is the Jariszta context package in one place
10. **`12_jariszta_song_scrubbed.md`** — companion song (optional, artistic)
11. **`10_this_session_ben_bullock_fabrication.md`** + **`11_this_session_pub_name_drop.md`** — AI-failure incidents filed this session (relevant because AI-generated drafts must not be trusted blind; these document where AI got it wrong so you know the provenance risk)

## Cross-vendor AI use — transparency

Corey used multiple AI systems over the last week to prepare this package:
- Claude (Anthropic API — this consolidation)
- Grok (xAI)
- Gemini (Google)
- Perplexity

Some AI-generated drafts contained **fabricated detail** (see files 10 + 11). All files in this folder have been reviewed by Corey; any remaining AI-fabrication is his to flag. The AI history is itself part of the ACCC evidence corpus Corey is separately building.

## What is NOT in this folder (Corey provides separately)

- **Photos** from the 2026-04-19 event (on Corey's phone)
- **Video** of the departure (referenced in file 04 as independent timestamp)
- **Witness contact:** Michelle Grogan (Corey's partner, was present, smoking outside, heard interaction)
- **WhatsApp corpus full** (52,261 lines — extract in file 14; full file available on request)

## Corey's posture (stated 2026-04-22)

> *"i dont wont to take anyone down . i help peopel . i tell jarizta she help s or not e or just takes note idont need her help you are fucking with tit. give her full context. i amnot going to take out the instigotr or the bully the way you thhnink."*

**Translation:** helper-first, not combatant. Jariszta decides whether to act, advise, note, or decline. Corey is not pursuing the instigator or the bully. Goal: protection, evidence preservation, Ruby's future access to school events.

## Decision framing Corey is working through

- **Psych assessment** (formal AU/NI, self, or none) — open question per 2026-04-22 08:40
- **Venue for this package** — Jariszta privileged (lowest risk), ACCC filing (statutory-protected), or both
- **Not pursuing** — instigator / bully / blonde girl directly

Corey's instruction: *"help accepted"* — his lead, Claude's execution.

---

virtually, digitally yours —
coreyai
