# IDENTITY RESOLUTION — 2026-04-19 Bookshop Incident
Prepared: 2026-04-20 | Known vs Unknown | DO NOT fabricate — mark unknowns explicitly.

## KNOWN identities
| Role | Name | Source |
|---|---|---|
| Subject | Corey McIvor | Self |
| Partner | Michelle Grogan | `user_full_profile_from_claudeai_memories.md` |
| Minor daughter (witness, heard slur) | Ruby | `user_family_context.md` |
| Minor son (witness) | Wesley | `user_family_context.md` |
| Prior legal counsel (standby only) | Benjamin Bullock | `user_legal_history_charges_wiped_ben_bullock.md` |
| Venue (location anchor) | "Bottoms Up", San Juan del Sur, Nicaragua | Incident file |

## UNKNOWN identities (require extraction from WhatsApp corpus before final notice)
| Role | Status | Notes |
|---|---|---|
| School name (if event was school-linked) | **UNKNOWN** | ~20 "pro-school" red-shirt kids present suggests school-affiliation |
| Principal / school administration contact | **UNKNOWN** | Required for `LEGAL_NOTICE_FINAL_2026-04-20.md` `[Principal Name]` field |
| Girl who made the "appropriate" accusation — **"pigtail girl"** | **UNKNOWN name**, description = pigtails, on-camera line *"please don't film me"* | Age uncertain (adult/teen/minor — fact-check before any naming) |
| Lady who yelled *"Sir, sir, sir, sir"* | **UNKNOWN** | Described as girl's mother or female associate |
| Adult male #1 — **"puffed-up black shirt man"** (made threat *"I will kick your fucking ass"*) | **UNKNOWN name**, description = black shirt, visibly puffed up on video | Primary assault-threat subject. Corey posture post-review: documented but not being pursued — called "legend" for bull-fix instinct |
| Adult male #2 — **"logical man"** (said *"it's a bunch of kids, there is no logic"*, stood to Corey's LEFT on camera) | **UNKNOWN** | Concession witness. Corey post-review: "real champion" — his logic settled the situation |
| Person who jumped on Corey's car bonnet | **UNKNOWN** | Property interference witness |

## Extraction source to mine
- `~/Desktop/GOOGLE_SUPERINTELLIGENCE_DROP_2026-04-20/ZYNRIP_WHATSAPP_MESSAGES.md` (52,261 lines, 3.9MB)
- `~/Desktop/ZYNTHIO_ARCHIVE/ZYNRIP_20260403/04_FAMILY/whatsapp/Logs/` (raw export)

## Recommended search patterns (for NotebookLM/Gemini or next agent)
- "Bottoms Up" / "bookshop"
- "school" + "San Juan" / "SJDS"
- "principal" / "director" / "maestro" / "profesor"
- Names of Corey's 6 SJDS clients — cross-check they are NOT in today's crowd (per `user_full_profile_from_claudeai_memories.md`)

## Governance escalation path (Nicaragua, if school-linked)
1. School Director
2. MINED municipal/local delegate
3. MINED Rivas departmental delegation
4. National MINED if unresolved
