# 21 · PETER'S SELF-CONTRADICTION IN 21 MINUTES

**Filed 2026-04-23 ~11:15 CST. Short file. Corey's own pattern-read on Peter's two pieces of written communication, captured verbatim.**

---

## The two statements from the same sender, 21 minutes apart

### 10:38:14 — written WhatsApp to Corey
> *"As for the incident you speak of, **I am not sure of the details as I was not made privy to them**."*

Peter disclaims knowledge. Careful legal phrasing. Positions himself as *not* a knowledge-holder on Corey's 2026-04-19 matter.

### 10:53:16 — voice message from Peter (deleted later; preserved in file 20)
> *"probably what he deserves"* [re: being called pedophile]
> *"I think he's on a fishing trip"*
> *"we need to protect our kids from super creepy pedophiles like this"*

Peter now pronounces judgment + uses the word "pedophile" about Corey to a third party + calls for protection-of-kids-from-Corey.

## The contradiction (plain reading)

You cannot in the same thread:
1. Disclaim knowledge of details, AND
2. Pronounce that the accused *"probably deserved"* a defamatory label, AND
3. Categorise him as a *"super creepy pedophile like this"*

You can only do (1) OR you can do (2)+(3). Doing both is an admission that (2)+(3) were reached **without** the knowledge (1) says he lacks.

## Plain-English label for the pattern

Corey's doctrine (per `memory/user_family_michelle_nick_bull_dynamic_20260417.md`):
> *"Bull personality pattern: charge-at-red-flag, don't-listen-to-end."*

Peter's 21-minute arc is the textbook version in writing:
- Red flag: Corey wrote "lawyer" and "2026-04-19"
- Charge: voice message 15 minutes later with "pedophile" language
- Admission (earlier, same thread): "not made privy to details"

Peter is demonstrating the Bull doctrine on himself, in writing, with a timestamp.

## Why this is one file not one line

Because it's the clearest single-page argument a lawyer can hand a court:
- Two verbatim statements
- One sender
- 21 minutes apart
- Internal contradiction
- Preserved with chain-of-custody
- Accompanied by the voice file and transcript (file 20) so the second statement is verifiable audio not hearsay

## No claim this file makes

- No claim about the 2026-04-19 sidewalk incident itself (that's file 01)
- No claim about Paige (third-party source Peter named in the voice)
- No claim about whether Peter's organisation has process standing to "investigate"
- Only claim: the two statements from Peter cannot both be true at the same time as written

## Chain of custody

- Voice: preserved in WhatsApp export zip, unzipped into `whatsapp_export_peter_20260423/`, transcribed file 20
- Text: preserved in same `_chat.txt` from the export
- This analysis: written by Claude Code CLI at Corey's direction 2026-04-23 ~11:15 CST

---

**End of file 21. This is a supporting file for file 20, not a replacement.**
