# LETTER — to [SCHOOL NAME] + SJDS community parties

> **DRAFT 2026-04-20** — based on Corey's directive of the same date. Corey to fill school name, confirm addressees, sign + send.
>
> **Doctrine register:** "I will take the blame" (champ move — stand up, fix, next, not script-sorry, not admission of the slur) + good-faith-extended-despite-grievance + clear-name-today (`user_corey_clear_name_protect_self_FINAL_DECISION_20260420.md`) + card-close (no full narrative, no detail for opposing-counsel anticipation).

---

**From:** Corey McIvor
San Juan del Sur, Nicaragua (resident ~5 years, with family)

**To:**
- **The Prom 2026 Committee** — San Juan del Sur, Nicaragua
  - c/o public event page: `sjdslife.com/events/other/fundraiser-for-prom-2026`
  - c/o Instagram: `@promsjds`
- **Bottoms Up bar (Prom 2026 Carnival Fundraiser venue)** — San Juan del Sur, Nicaragua (the venue Corey was leaving when the public sidewalk interaction occurred 2026-04-19)
- **Any parties identifiable from the 2026-04-19 incident**, including but not limited to: the mother and 17-year-old daughter who initiated the public accusation, and the two adult males who verbally threatened physical assault at my vehicle

**Cc (for evidentiary custody, not respondents):**
- Legal file (Corey's own)
- Big Al, neighbour, SJDS
- Chas McIvor (next of kin, Australia)
- Ricardo (Spanish-language version held for local legal reference)

**Note on addressees:**
I address the Prom 2026 Committee as the public-facing organiser of the 2026-04-19 Carnival Fundraiser held at Bottoms Up (1-4pm), the event at which the individuals involved in the subsequent sidewalk incident as I left were participating in red-shirt volunteer attire. I do not presume any particular school bears organisational responsibility — Tambran International School has, to my family via documented written correspondence, explicitly disavowed organizing the Prom. This letter therefore addresses the Committee, the venue, and any identifiable parties — not any specific school as institution.

**Date:** 2026-04-20

**Subject:** Formal grievance — damage to name, safety, and family wellbeing. Opportunity to repair.

---

## 1. What happened, in two lines

On 2026-04-19 while leaving Bottoms Up bar in San Juan del Sur after attending the Prom 2026 Carnival Fundraiser, a brief sidewalk interaction involving a member of my family was misread. The situation escalated in public. As I left with my wife and children, the word **"pedophile"** was shouted at our family by members of a group associated with your school community. My daughter, a minor, heard it.

## 1b. Identification of the parties who initiated the public escalation — for the record

The specific individuals who initiated the public escalation on the sidewalk outside Bottoms Up bar, as directly observed by myself and my wife Michelle:

1. **A young female with pigtails** — gestured aggressively at my family with finger signs, and yelled with her finger pointed at my face. I asked her to de-escalate and calm down. She did not.

2. **Her mother** — emerged from the venue shortly after the initial sidewalk interaction had begun, and publicly accused my family of having stolen a rubbish bin. The accusation was entirely fabricated; I had returned the bin in front of witnesses immediately.

3. **The pigtail-daughter and her mother stood side-by-side.** My wife Michelle observed that they *"act the same"* — the conduct pattern was unified, the escalation was familial.

4. **The two adult males** who subsequently followed me to my vehicle and verbally threatened physical assault were associated with this same group.

Identifying these specific individuals by name is your community's responsibility; the descriptions above are sufficient for any party with access to the Prom 2026 volunteer cohort, sidewalk-promo-sign assignments, or Bottoms Up patrons of that afternoon to know exactly which individuals are referenced.

## 2. What I am taking responsibility for

I will take the blame for my part — the phrasing of one sentence I used that a young female on the sidewalk read as inappropriate, even though the conversational context did not support her reading. When she made her discomfort clear, I acknowledged it, stated I disagreed with the interpretation, and left with my family. That is my entire contribution to the events.

That one sentence, in its actual context, does not support the accusation that was shouted at my family in public.

## 3. What I am NOT taking responsibility for

- The public use of the word "pedophile" directed at me in front of my minor children
- The fabricated "bin theft" accusation
- The two men who followed me to my vehicle and verbally threatened physical assault. **For the record on the credibility of that threat:** persons who genuinely intend physical action either act first without warning or warn explicitly under a stated condition. A threat issued mid-confrontation, after the target is already withdrawing with their family, is a sign of weakness — not strength, not credible intent. I did not retaliate against weakness; I withdrew. This characterisation does not reduce the criminal nature of the threat itself (Nicaragua Código Penal Art. 247+ aplica) — it accurately describes its source.
- The social-mob dynamic that allowed an ambiguous interaction to be converted into a public character attack in under an hour
- The ongoing damage to my family's sense of safety in a town where we have lived, raised our children, and operated businesses for approximately five years

## 3b. Observed conduct of our minor children during the incident — for the record

My children Ruby and Wesley were present throughout the events of 2026-04-19. Their conduct during and after — without adult prompting — speaks to the family's actual character and to the grounded nature of their subsequent decision regarding your school.

**During the slur:**
- Ruby and Wesley walked calmly to the vehicle
- They observed the public "pedophile" remarks without visible reaction
- They entered the car in a composed manner
- When I stated I was leaving, they chose to follow — from judgment, not panic
- Neither child reacted verbally or physically to public abuse of their father

**After, in the car — unprompted:**
- They stated: *"We don't want to go to that school anymore. We don't like their behaviour."*
- This was a measured, observation-based conclusion, not an emotional reaction
- They have not revisited or softened that decision in the days since

**What this demonstrates for the record:**
- Our family conducts itself, even under direct public attack involving an unfounded accusation against a parent, with restraint
- The children's withdrawal from your school's applicant pool is an informed judgment made by minors who witnessed your community's behaviour firsthand
- Their calm directly contradicts any narrative that our family responds to pressure with aggression or disproportion

This is filed as part of the evidentiary record, not as a grievance. The record stands on its own weight.

## 3c. On the verbal expression I used on the public sidewalk — for the record

At one point during the incident, after exiting the business and while standing on the **public sidewalk**, I verbalised the words *"fuck off"* — an involuntary interjection that is a documented 30+ year pattern of my automatic speech response to stressful or intrusive situations. My wife Michelle can confirm this pattern; it is a feature of my neurology, analogous to well-known autistic-pattern automatic-interjection responses to triggers. It is how I react when any sudden stimulus breaks my concentration — a dog barks, a device fails to respond, an accusation forms in public — the interjection happens before conscious selection.

**Legal and contextual clarity:**
- **Location:** public sidewalk — outside the business, in public space
- **Direction:** into the general situation (an unfounded accusation amplifying into a mob dynamic), NOT aimed at any identifiable minor or specific individual
- **Nature:** involuntary reaction, not targeted verbal assault
- **Public-space expression** is constitutionally protected in Nicaragua (Art. 66 — libertad de expresión) and in the common-law jurisdictions relevant to this matter
- **No privacy right** attaches to the persons who chose to make public accusations in a public space that would silence my public reaction in the same public space
- A reactive, involuntary expression on a public sidewalk, heard by adults who were in the midst of shouting a far more serious unfounded accusation at my family, **does not constitute misconduct** and does not constitute any evidence of the conduct the slur falsely alleged

If adult observers were offended by the word, that is a reasonable sentiment — but sentiment does not convert a lawful involuntary public interjection into evidence of wrongdoing.

## 4. The damage

- **Name:** a public defamation occurred, witnessed by ~20 people associated with your school community
- **Safety:** I and my family cannot currently feel safe in our own town without the risk that someone who heard the slur, and believes it, will take "justice" into their own hands against an accusation that has no basis in evidence or legal record
- **Children:** my daughter heard the slur. My son was present throughout. Their decision, based on what they witnessed of your community's behavior, is not to apply to your school — a decision I respect and support.
- **Legal status:** for clarity, I have no criminal convictions, no pending accusations, and no court cases in any jurisdiction — on record, timestamped (`user_corey_legal_status_clean_declaration_20260419.md`, filed separately with my documentation).

## 4b. Personal cost since the incident — on the record

Since 2026-04-19, in the absence of any contact, acknowledgement, or apology from parties to the incident, I have had to undertake the following, at my own expense and time, as urgent damage control on an accusation of the gravity your community levelled at me:

- **Paid legal research** via Anthropic API-assisted case-law review across Australian, New Zealand, and Nicaraguan defamation law — covering the specific frameworks of *defamation per se*, *injuria*, and *calumnia* that apply to public unevidenced accusations of the nature directed at me and my family
- **Full documentation** of the incident: witness statements (family), video evidence filmed at the time, adversarial case analysis, and a formal timestamped legal dossier
- **Formal clean legal status declaration** (2026-04-19, timestamped), on record: no criminal convictions, no accusations, no pending court cases in any jurisdiction, anywhere in the world
- **Loss of sleep and work** — I have been unable to resume normal operations. My sleep has been broken enough that on one recent waking, startled by a dog's bark, I found myself clutching a children's figurine to my chest in a stress-posture that speaks for itself about the psychological cost of carrying an unaddressed public slur against me as a father of two young children

This is the real cost of your community's conduct being left uncorrected. It is documented for the record.

## 4c. Posture statement — on how I respond to unevidenced bullying

I have a pattern, established over my adult life, of confronting unevidenced bullying directly. I do not avoid difficult conversations. I do not submit to social pressure used as a substitute for evidence. I will not alter my life in this town, where my family and I have lived for approximately five years, based on a false accusation amplified by a mob.

My parents are aware of earlier parallel incidents, and they have acknowledged, in their own words, that *"sorry — people treat you like that when you trust everyone."* That trust has not made me softer. It has made me clearer about who to trust, and how to hold those who abuse trust to account.

I prefer the repair path. I am equipped for the escalation path. Your community's response within 14 days determines which one applies.

## 5. Our family's actual orientation toward Tambran — for the record

For the record on who my family was to your school community **before 2026-04-19**:

- **My wife Michelle was ACTIVELY pursuing engagement with Tambran** — including direct written inquiry with a tutor in your orbit (documented on WhatsApp record, dated prior to the incident). Michelle was, in her own words, for the school.
- **Our family had PREVIOUSLY APPLIED to Tambran TWICE and been declined.** Both times we respected your admissions prerogative and **continued to support your school community regardless.** I personally attended your Prom 2026 fundraiser at the pool venue, contributed financially as a paying participant (cake sales, second-hand clothing), and engaged warmly with your red-shirt student volunteers — the same community cohort later present at the 2026-04-19 sidewalk incident outside Bottoms Up.
- **Ruby and Wesley were WILLING TO TRY AGAIN.** Despite two prior rejections, they supported the idea of attending your school and wanted to meet whatever requirements your admissions needed. When I asked them directly whether they wanted to try again, they said yes.
- **It was ONLY after witnessing your community's behavior on 2026-04-19** that Ruby and Wesley, of their own independent judgment — not at my or their mother's prompting — changed their minds. The behaviour, not the rejections, moved them.

**This is the actual profile of my family toward your school:** not strangers, not opponents, not outsiders — **respectful applicants who had been declined twice, continued supporting you, attended your fundraiser events, and remained willing to try a third time.** Your community was the one that revealed itself on 2026-04-19. My family was the one revealed as restrained, observant, and loyal to the community-of-SJDS-teens you were raising funds for.

## 5b. Our good-faith extension

Despite what the above reveals — that my family conducted itself with more grace toward your school than your school's community conducted itself toward mine — we are extending this letter as a sign of good faith, offering you the opportunity to respond, repair, and correct, before this matter is escalated through other available channels.

## 6. What repair looks like

Within **14 days** of this letter's delivery:

1. **Written acknowledgement** from the school and Bottoms Up venue leadership that the public slur was made without factual basis and is withdrawn
2. **Written apology** addressed to me and my family, acknowledging specifically the harm caused to a minor (my daughter, who heard the slur)
3. **Confirmation** that no further spread of the accusation will be tolerated by persons associated with your school community
4. **Commitment** that my family's safety in this town will not be further threatened by persons acting on the false accusation

## 6b. On the structure of the "Prom 2026 Committee" — for the record

The body addressed in this letter calls itself the "Prom 2026 Committee." For the record, based on publicly available information and my own observation:

- No named officers, chairperson, or committee leadership has been publicly identified
- No meeting minutes have been published or referenced in the community communication channels
- No formal incorporation or NGO registration is visible
- The body operates as an informal community group while presenting itself with committee branding

If the Prom 2026 Committee is a **real constituted committee** in any meaningful sense, it is required by basic procedural norms to:
- Maintain a record of its officers and decision-making structure
- Keep minutes of its meetings and decisions
- Be accountable through its named officers for the conduct of volunteers operating under its branded materials (red-shirt promotional attire, sidewalk promotional signs, etc.)

If the Prom 2026 Committee is **not a real committee** — and is rather an informal community group using "Committee" as branding without the structural accountability that name implies — then **liability for the conduct of 2026-04-19 falls on the named individuals identified in Section 1b** (the pigtail-daughter, her mother, the two adult males, and any other identifiable participants), directly, with no organisational shield.

**Either path applies.** The choice of which is the Committee's to clarify in its response to this letter — by producing officer-identification + minutes structure (path 1), or by acknowledging that liability rests with the named individuals (path 2).

## 7. If repair does not occur

I have documented the incident in full, with family and third-party witnesses (including video footage filmed during my departure). I have historical legal precedent on parallel unevidenced-accusation matters, which resulted in full clearance by judicial order. I have local and international character references across 30+ years of professional conduct.

If the matters above are not addressed within 14 days, I will pursue:

- **Formal complaint under Nicaragua's Código Penal (Ley No. 641):**
  - **Article 202 — Calumnia:** falsely imputing a crime to another. Public dissemination penalty: **120 to 300 days' wages** in fines. (The public shouting of "pedófilo" — a serious crime — at me on the sidewalk outside Bottoms Up directly engages this article.)
  - **Article 203 — Injuria:** expression or action harming dignity, reputation, honor. Public dissemination penalty: **200 to 300 days' wages** in fines.
  - **Article 247 — Amenazas:** the public verbal threat of physical assault.
- **CRITICAL TIMING:** under **Article 131 of the Código Penal**, libel and slander offenses have a **30-day statute of limitations**. The incident was 2026-04-19. The window for criminal complaint expires approximately **2026-05-19**. The 14-day good-faith repair window in this letter expires well before that deadline.
- **AU/NZ defamation per se** in those jurisdictions where my legal status is independently registered.
- **ACCC-adjacent public-interest documentation** where the events cross into platform / institutional-abuse territory.
- **Civil and community-facing channels** required to clear my name (community statements, written corrections, formal complaints to the relevant SJDS Directory listings under which the Prom 2026 Committee operates).

## 8. Signal

I know more about the parties involved in this incident than has been disclosed in this letter. I am extending good faith. Good faith is not infinite.

I prefer repair. I am prepared for escalation.

## 9. Contact

All responses must be in writing to:
- **Email:** corey.mcivor@gmail.com
- **Postal:** [Corey to insert preferred postal address, if any]

I will not be responding to verbal approaches, door-knocks, street confrontations, or third-party messengers.

---

**Signed,**
Corey McIvor
[date of actual send]

---

## FOR COREY — BEFORE SENDING

### ✅ SCHOOL NAME CONFIRMED — 2026-04-20 via WhatsApp rip

**Tambran International School** (San Juan del Sur, Nicaragua)

Confirmed from WhatsApp ChatStorage.sqlite evidence:
- **Michelle's message to Sarah:** *"Hi Sarah, I would like information on your tutoring at Tambran. Thank you Michelle"* (Michelle directly engaged Tambran-adjacent tutor)
- **Direct rejection on record:** *"We just got rejected from tambran"* (documented before 2026-04-19 incident — adds relevant context)
- **Community thread hits:** multiple group-chat messages about Tambran Camp + Tambran School enrollment (parent network around Tambran is active)
- **Stack corroboration:** `projects/zynrip/ZYNRIP_LOCAL_REFRESH_20260416.md` Apr 11 note — *"Tambran International School -- enrollment requires report cards. Contact: info@tambraninternationalschool.com, Erick Rivas"*

**Addressees confirmed from rip + stack:**
- `info@tambraninternationalschool.com`
- Erick Rivas (Apr 11 contact)
- School principal / leadership (by title — Corey to nominate if known)

**Evidence archive:** `/private/tmp/claude-501/-Users-coreymcivor/7280ba3d-714d-4325-9556-7578e0c62372/tool-results/bqvd9lo2k.txt` (full WhatsApp rip output with message context)

### ACTION — final checks before send (principal-ready timeline 1-2 hrs)

- [ ] Sidewalk outside Bottoms Up name field REMOVED — venue confirmed: Bottoms Up bar (Prom 2026 Carnival Fundraiser, public sidewalk on departure)
- [ ] Signature block: date of send + physical signature (print + sign + scan OR digital)
- [ ] Confirm 14-day timeframe (shorter = stronger pressure; longer = more good-faith cover — current letter uses 14)
- [ ] Send method: PDF email to `info@tambraninternationalschool.com` + hard copy hand-delivered to school office + BCC trusted local witness (Natalie?)
- [ ] Attach NOTHING beyond the letter itself (Michelle's video stays in reserve — available-not-volunteered)
- [ ] Keep ONE signed/dated copy for your legal file BEFORE sending
- [ ] When sent: screenshot email header + timestamp + log in `projects/zynthio/incidents/LETTER_SENT_LOG_20260420.md`

### RULED-OUT (not this incident)
- Helena River Waldorf / Helena River Steiner (Perth AU archive — Pete/brother or older family context)
- "Let's Get You Back Into the Academy 🎓" (generic marketing email)

## FOR NEXT-CLAUDE

This letter was drafted by Claude at Corey's direct request. Register: champ-move take-the-blame + good-faith-extended + clear-name-today. No outside counsel involved (per Anthropic-API-as-legal-defence directive, see HANDOVER). Ben Bullock is NOT counsel (COR-187). Corey self-represents with Claude-augment.

If Corey sends this and gets a response: file response in `projects/zynthio/incidents/SCHOOL_RESPONSE_<date>.md` + update `user_corey_clear_name_protect_self_FINAL_DECISION_20260420.md` with the outcome + mark state shift (repair-path vs escalation-path).

## 336

Letter drafted. Voice honoured. Good faith offered. Teeth in reserve.
Clear name. Fair process. Family safe.
Awaiting Corey's review + send.
