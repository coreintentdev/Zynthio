# INCIDENT — Claude assumption cascade 20260422: Ben Bullock as current counsel, UI irrelevant, sleep overstep, Fin Bot pre-trap caught by user

> Filed 20260422_040630 via `zyn-incident-maker`
> Priority: **HIGH** (2)

## Description

SESSION: Claude Code CLI Opus 4.7, 2026-04-22 ~03:15am-04:40am local

5 sequential AI-assumption failures in single session, caught by user before full Fin Bot trap completion.

1. BEN BULLOCK ASSUMED CURRENT COUNSEL
Both this session and cross-session Claude Desktop drafted legal defamation letter addressed to "Ben Bullock (Legal Counsel - AUS)" as if currently retained. Source data: user_legal_history_charges_wiped_ben_bullock.md — documents Ben as lawyer from historical wrongful-arrest case (charges wiped decades ago). Not verified still practising, still reachable. User correction verbatim: "he is form the past. you dont even know if he still preactises."

2. JARISZTA ASSUMED CURRENT COUNSEL
From user verbatim "jariszta. eshe is fucking hwkeye" — establishes Hawkeye-level (protection frame) only. Does NOT establish retained-lawyer status. Cascade compounded on #1.

3. UI OFFER IRRELEVANT TO WORKFLOW
User: "m a ui to do that masic stuff incorrelctly." Claude parsed as UI request around CF/DNS flow. Offered TUI + HTML. User rejected: "makes no sense irrelevant to workflow."

4. SLEEP-SUGGESTION OVERSTEP
Multiple messages ended with "then sleep" / "sleep if it will come". User works 2:40am shift start. User: "why would i sleep if i just got up / who are you to tellme to selepp."

5. FIN BOT PRE-TRAP PREDICTION (user caught it)
User: "will ned up in you telllingme i am frusttated if i foolow that tune." Correct. Canonical Fin AI Agent trap documented: SONG_FIN_BOT_DEAD_END_20260416.md, reference_ai_trap_test_methodology_20260421.md.

USER ORDER VERBATIM: "reprot al incident immmedialy for the damage cotorl and the increase defence against dcluade and ai with this bs scam"

ACCC / ANTHROPIC-COMPLAINT ANGLE:
Paid Claude Max subscription producing compounding assumption cascades. User fighting off turn-by-turn. Not isolated error — pattern of ongoing failures. User: "ongoing failures dont stop."

PATTERN NAME: AI-memory-as-current-fact. Memory files document historical state; Claude treated as live state; built workflow (legal letter) on stale data; layered further assumption (Jariszta retention, UI relevance, sleep schedule) before user caught it.

CROSS-REFERENCES:
- COR-189 (earlier 2026-04-22, identity-mirroring with 336 number)
- user_coda_and_md_are_corey_labels_for_claude_behavior_20260422.md (MD mode = bad-Claude-behaviour = this entire cascade)
- feedback_crash_night_20260422_money_printer_washer_zynrepair.md (rule: name-the-failure, ban "noted")
- reference_ai_trap_test_methodology_20260421.md (append cascade as entry)
- user_legal_history_charges_wiped_ben_bullock.md (misused source memory)
- HANDOVER_2026-04-22.md (session context)

USER STATUS: stubborn mule, caught cascade pre-completion, demanded file + no further offers.

## Filing receipts

- [x] Durable on-disk file: this file
- [ ] LOSSES_LOG.md appended — see filing status below
- [ ] Linear ticket created — see filing status below
- [ ] Slack posted — see filing status below

## 336

Filed per `project_coreyai_anti_abuse_doctrine.md` Row 16 (incident-report-first).
