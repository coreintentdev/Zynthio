# WhatsApp corpus extract — market-stall / Prom 2026 / Bottoms Up / Apr 19 fundraiser

**Source:** ZYNRIP_WHATSAPP_MESSAGES.md (52,261 lines total)
**Extract method:** grep on anchor-terms (Prom 2026, Bottoms Up, carnival, April 19, fundraiser) + ±10 line context
**Purpose:** Jariszta evidence — 2026-04-19 defamation incident witness-chain

---

## Prom 2026 / Carnival Fundraiser broadcasts + reactions

752-[2026-03-26 22:08] [RECV] 5-2-7: I’m coming with a friend
753-[2026-03-26 21:45] [SENT] 5-2-7: One more
754-[2026-03-26 21:37] [RECV] 5-2-7: See you all soon.  Looks like we have at least 4 this evening
755:[2026-03-26 20:48] [RECV] Palermo & Friends Buy and Sell: The Prom 2026 Committee is now accepting donations of gently used items that can be used for the Fundraiser Garage Sale. If you have some books, sporting equipment, household items, Kitchen gear or anything that you would like to donate we would greatly appreciate it. We have set up some drop off locations that will accept donations during their business hours as well as I can do pick ups of donations by messaging me directly.We want the Fundraiser to be a huge success and having a great selection of resale items will be a major portion of the event. So clean out those closets and cupboards and let's help an amazing cause to keep Prom 2026 affordable for all area high school students!! Thanks in advance for your generous donations!
756-[2026-03-26 20:29] [RECV] Natalie D. Sullivan Natalie: this morning while I was out walking I received a message from Google that someone was trying to access my account so I changed my password.
757-[2026-03-26 20:29] [RECV] Natalie D. Sullivan Natalie: Good afternoon
758-[2026-03-26 20:00] [RECV] +505 8698 0295: Hola puedes comprar arroz y aceite te oliva por favor 🙏🏻
759:[2026-03-26 19:19] [RECV] Palermo & Friends Buy and Sell: Mark your calendars....Prom 2026 Committee will be putting on a Carnival Fundraiser to raise money for the Prom 2026 for all area High School students. This Carnival fundraiser will be hosted at Bottoms Up in town on April 19th, 1pm to 4pm. Come down and get your car washed, buy some baked goods and plant, have a burger and play some games! Amazing Raffle Prizes will be up for grabs so make sure to check that out!
760-[2026-03-26 18:51] [RECV] Corey & Michelle House Hunting: this morning while I was out walking I received a message from Google that someone was trying to access my account so I changed my password.
761-[2026-03-26 18:51] [RECV] Corey & Michelle House Hunting: Good afternoon
762-[2026-03-26 18:38] [RECV] Palermo & Friends Buy and Sell: You can find some at the Chinese store in town
763-[2026-03-26 18:26] [RECV] Palermo & Friends Buy and Sell: I am looking for a 2nd hand phone or tablet - basic one - just need it to run 1 application.  Must be Android
764-
765-And still looking for bookshelves
766-[2026-03-26 18:19] [RECV] Palermo & Friends Buy and Sell: Anyone have a Happy Birthday or Birthday Girl headband for sale?
767-[2026-03-26 17:17] [RECV] Palermo & Friends Buy and Sell: if you do not find them ... I am driving to wallmart on Monday
768-[2026-03-26 17:08] [RECV] Palermo & Friends Buy and Sell: Hi there beautiful souls...anyone coming from the USA in the next  week that can bring me an envelope with medicine for Pinky Dinky Darling the Derby Woolly Opossum in our sanctuary please. I can have it mailed to an address in the US.
769-
--
13989-[2025-12-12 18:36] [RECV] Palermo & Friends Buy and Sell: I would like to 1 litter of hand wash , and small shampoo to try . Pickup tomorrow at farmers market
13990-[2025-12-12 18:31] [RECV] Palermo & Friends Buy and Sell: 👀 Come visit Poco Coco at these upcoming events 
13991-
13992:🐶🎄 TODAY - Dec 12th - SOS Animales Holiday Hope Fundraiser | 5pm - 10pm 😻 25% of sales will be donated to SOS + silent auction items available too!
13993-
13994-📅 TOMORROW - Dec 13th - SJDS Farmers Market | 9am - 12pm
13995-
13996-📅 Saturday, Dec 20th - Hacienda Iguana Community Market
13997-
13998-Each of our home & personal care products is made with 100% natural, plant & mineral-based ingredients, completely non-toxic, biodegradable, and scented with essential oils. 
13999-
14000-Our formulas are free from synthetic scents, parabens, sulfates, PEGs, silicones, phthalates, microplastics, artificial colours, and other harsh chemicals - giving you clean, conscious cleaning essentials you can trust.
14001-
14002-Proudly made in Nicaragua, our range includes:

---

## Pedophile / accusation / sidewalk / ban-related

6651-
6652-Tomorrow (Monday) night! Try to get here just before 6pm, as I am hoping to start these movies about 20+ minutes after sunset each time, so let that be your Chrono O'clock for Conan O'Brien.
6653-
6654:• "If I Had Legs I'd Kick You" / 91%RT / youtu.be/ywFDoT7LBbQ
6655-[2026-02-08 22:27] [RECV] Palermo & Friends Buy and Sell: Hello everyone 💕 These are the retreats we have scheduled for this year so far, April and July, five days of rest, nourishment, movement, and meaningful connection for women ready to choose themselves. If you or someone you know might benefit, DM me for more details 🤍
6656-[2026-02-08 21:11] [RECV] Palermo & Friends Buy and Sell: Happy Sunday 🌺
6657-
6658-Can I please place an order for French Kiss and Love at First Sight?
6659-[2026-02-08 19:30] [RECV] The Palermoz 😍🦋: Hi! Looking for a place to rent, family of 5. 
--
13561-	•	18 Vanguards match: ~$24,750 value
13562-	•	18 Titans match: ~$81,000 value
13563-
13564:And the kicker: the submission cost over 90 days is tiny compared to that value (she threw out under ~$700 even with Titans).
13565-
13566-⸻
13567-
13568-🚨 Promo Rules (This is where people mess up)
13569-
--
32401-https://usa.yamaha.com/products/musical_instruments/keyboards/portable_keyboards/psr-e443/index.html
32402-[2025-04-14 00:58] [RECV] Palermo & Friends Buy and Sell: I’d like to talk to her Ed.
32403-[2025-04-13 23:12] [RECV] Palermo & Friends Buy and Sell: Is anyone looking for a Cook/housekeeper? When I leave on May 14, the lady who has worked for me for three years will be available for a new job.  She works for me five days a week 7 till 3, she prepares all the family meals, cleans the house and is a very good cook, (she has worked in two restaurants in town) . She is Very reliable and has become indispensable for a busy family house. DM if you would like to hire her.
32404:[2025-04-13 22:43] [RECV] Palermo & Friends Buy and Sell: Tonight!! 6:30 on the sidewalk🎷🎸🎶
32405-[2025-04-13 22:43] [RECV] Palermo & Friends Buy and Sell: https://www.facebook.com/share/18cLHM2ozJ/
32406-[2025-04-13 22:00] [RECV] +505 8351 3162: Cheers Corey! Will make a list and be in touch
32407-[2025-04-13 20:47] [SENT] +505 8789 8913: Ok
32408-[2025-04-13 20:46] [RECV] +505 8789 8913: I will talk to her about prices when she gets home later today and I'll get back to you.
32409-[2025-04-13 20:44] [SENT] +505 8789 8913: I respect that🥹
--
34616-[2025-03-06 18:49] [RECV] +505 8815 4416: Ok, I well keep Sonia's mitts off it if you have to wait until tomorrow
34617-[2025-03-06 18:48] [SENT] +505 8815 4416: Our car just broke down. Corey is on the road with a friend trying to fix it. Will let you know if i can come before 3pm. If you dont hear, that means another time
34618-[2025-03-06 18:46] [SENT] Palermo & Friends Buy and Sell: Excelente
34619:[2025-03-06 18:33] [RECV] Palermo & Friends Buy and Sell: See y'all tonight at 6 on the sidewalk for great music and excellent food😋
34620-[2025-03-06 18:32] [RECV] Palermo & Friends Buy and Sell: https://www.facebook.com/share/14RBPdtSuX/
34621-[2025-03-06 18:25] [RECV] Australia McIvor: I cant walk home because i dont have shoes. Too hot for me
34622-[2025-03-06 18:25] [RECV] +505 8815 4416: I got wrapped up with my cargo shipment issues,  Mom and Stacey this morning. If you can come before 3 that would be great. I am supposed to meet Siem just after 3
34623-[2025-03-06 18:25] [RECV] Australia McIvor: We are stuck on the sode of tge road near hasons house. Trying to fix the car
34624-[2025-03-06 17:51] [RECV] +1 (786) 223-5413: When I can see you?
--
39579-[2024-12-16 03:16] [RECV] 🍿📽️Outdoor Movie Night SJDS: We don’t wanna watch your old ass
39580-[2024-12-16 03:03] [RECV] The Palermoz 😍🦋: 86400
39581-[2024-12-16 03:00] [RECV] 🍿📽️Outdoor Movie Night SJDS: This is a great movie. My friend worked on the production. We won't be able to make it tomorrow but great choice Jimmy. 👌
39582:[2024-12-16 02:30] [RECV] 🍿📽️Outdoor Movie Night SJDS: Fusun wants to go to Pane Nostro for their Sidewalk Sessions this Monday night, but we also want to watch a movie at home this Monday as well. So why not both?🤷‍♀️ As long as we start around sunset (5:15!), we can sneak one in before the event.
39583-
39584-5:15pm to 6:45 we will be watching My Old Ass. I should only have to say "Aubrey Plaza", but not everyone shares my kind of interests. So let me add a secondary description; 18-year-old meets her 39-year-old self on a mushroom trip. Hilarity ensues, I assume.
39585-
39586-• "My Old Ass" / 90%RT / youtu.be/Yvks3SeCDOs
39587-[2024-12-16 02:26] [SENT] +505 8147 1809: It was fun thank you for wanting to learn, you are improving already. I like your attitude on the court
--
40516-[2024-12-10 19:32] [RECV] +505 8375 7148: I think at this point, we are done communicating dear, have a nice day
40517-[2024-12-10 19:31] [RECV] +505 8375 7148: I’m responding you with communication, so, forward away, if you can’t handle reality Michelle
40518-[2024-12-10 19:30] [SENT] +505 8375 7148: No
40519:[2024-12-10 19:30] [RECV] +505 8375 7148: Let’s leave things in writing, to start Michelle….. the last call I took from you, you flew off the handle on me accuse me of losing $10,000 when you really only invested 2500 and that was an excuse that you gave me instantaneously blaming me and justifying you stealing my idea
40520-[2024-12-10 19:28] [RECV] +505 8375 7148: What needs to be addressed? The perception of people responses to your actions, like these reactions form a small knit PB community in sjds? This what your trying to do damage control?
40521-[2024-12-10 19:28] [SENT] +505 8375 7148: From now I wish only to communicate to you in person tank you
40522-[2024-12-10 19:27] [SENT] +505 8375 7148: I feel this need to be addressed today, I can make myself available when you are free to meet in person?
40523-[2024-12-10 19:16] [SENT] +505 8375 7148: Sure id love to discuss it in person
40524-[2024-12-10 19:15] [RECV] +505 8375 7148: I think I said all I need to say to you, thank you. But….if you are wanting to meet, to apologize of being a shit friend, stealing my idea, posting your biz plan not having the common decency of communicating your intentions and lack of acknowledging this, launching the very thing I told you I was doing, your actions/video absolutely speak to the 3 weeks of what I gave you, and concept of my rental business ….yes was “the education” you tell me I didn’t give you 🤣… I will meet, other than that, not interested…
--
48975-
48976-El recorrido pasará a las 2:30pm
48977-Buenas Noches
48978:[2024-11-05 22:08] [RECV] Kelly Almeida: Orzero Steps Counter Compatible for Po-ke-mon Go Walker Phone Swing Accessories Cellphone Pedometer (USB Cable) (Easy Installation) (Mute Version) Egg hatcher Rocker Quick Steps Earning Device - Black 
48979- https://a.co/d/e4P0Ky1
48980-[2024-11-05 22:05] [RECV] Maderas M-F Pickleball 9am: Actually let’s make it 7:00
48981-[2024-11-05 22:03] [RECV] Maderas M-F Pickleball 9am: We’re here and would like to hold the court till 9:00
48982-[2024-11-05 21:55] [RECV] Group Pickleball: Join me for pickleball Wed, 11/06/2024, 10:00 AM at:
48983-San Juan del Sur, Nicaragua 

---

## Photos / minor / girl / 17|18 context

766-[2026-03-26 18:19] [RECV] Palermo & Friends Buy and Sell: Anyone have a Happy Birthday or Birthday Girl headband for sale?
767-[2026-03-26 17:17] [RECV] Palermo & Friends Buy and Sell: if you do not find them ... I am driving to wallmart on Monday
768:[2026-03-26 17:08] [RECV] Palermo & Friends Buy and Sell: Hi there beautiful souls...anyone coming from the USA in the next  week that can bring me an envelope with medicine for Pinky Dinky Darling the Derby Woolly Opossum in our sanctuary please. I can have it mailed to an address in the US.
769-
770-Thank you in advance.
771-[2026-03-26 17:06] [RECV] Palermo & Friends Buy and Sell: Any doctors in Rivas or San Juan who are good at stitches?
772-[2026-03-26 16:52] [RECV] Palermo & Friends Buy and Sell: Nica Travel Solutions Will make an extra shopping trip to Managua  this week on Sunday March  29th ,send us your order before Sunday, thank you and have a great day
--
786-
787-He'll be flying in from Colorado Springs, Colorado
788:[2026-03-26 04:20] [RECV] Palermo & Friends Buy and Sell: Is anyone coming from the US in the next few days or week that can bring me an envelope with medicine for Pinky Dinky Darling the Derby Woolly Opossum in our sanctuary please. I can have it mailed to an address in the US.
789-
790-Thank you in advance.
791-[2026-03-26 01:13] [RECV] Palermo & Friends Buy and Sell: I want it where can i pick it up ?
792-[2026-03-26 01:02] [RECV] Palermo & Friends Buy and Sell: I’ve got a decent iPhone bought for my wife but can’t use it here because it doesn’t accept a physical sim I’ll send the details soon 👍
--
833-[2026-03-24 18:31] [RECV] Palermo & Friends Buy and Sell: 186458069573752@lid
834-[2026-03-24 14:09] [RECV] +505 8829 7244: Hola buenos dias llegare por la tarde para tu camioneta lan cruser att Ricardo
835:[2026-03-24 14:04] [RECV] Palermo & Friends Buy and Sell: Hi I’m looking to buy some used items- shelves, desks and chairs - fans- if anyone is selling any please send me a private message 🙏🏻
836-[2026-03-24 03:03] [RECV] 🍿📽️Outdoor Movie Night SJDS: 😆
837-[2026-03-24 03:02] [RECV] 🍿📽️Outdoor Movie Night SJDS: Correction, Lawnmower Man came out in '92 😳
838-youtu.be/loK2VhHxVS0
839-
--
1589-[2026-03-17 17:24] [RECV] Palermo & Friends Buy and Sell: I highly recommend Dr Diego Valle in Managua
1590-[2026-03-17 17:21] [RECV] Palermo & Friends Buy and Sell: Here are some @158248858578963 
1591:https://nicaseeker.com/search-result-2/?directory_type=services&q=eye&in_cat=&radius-search-based-on=address&miles=0-0&in_loc=
1592-[2026-03-17 17:13] [RECV] Palermo & Friends Buy and Sell: Hi everyone! Can anyone recommend a good eye doctor?
1593-[2026-03-17 16:48] [RECV] Official Pickleball LAS ESCADAS  info Group: I can play tomorrow
1594-[2026-03-17 16:19] [RECV] 🧋Teen gathering events SJDS: Sounds good Robin, thank you so much ! Yes we gotcha and everyone that has paid a deposit or reached out to Val or myself direct we have you on the list. Just wondering Michelle if you guys are still in @267263047389406 & @67087808610532 If you can let us know awesome! If not still come 🩷🩷🩷 &  a reminder to all it's 130pm THIS Saturday :) at the field! Woot woot
1595-[2026-03-17 15:51] [RECV] Palermo & Friends Buy and Sell: FYI they are still working on the sirens today incase you hear them, please do not be alarmed.
--
1904-🧃 Bar will be open. You may bring in your own thermos, but not packaged products. No food and drinks allowed in the complex
1905-
1906:🛅 Las Escadas Pickleball will provide lockers for players ( No  extra fee) , pls take your own lock and keep your things in a safe place. Keep the chairs and tables free of belongings .
1907-
1908-🐶 Pets not allowed in the courts. It should be supervised and with leash all the time. Acces to Codominiums is restricted
1909-
1910-Pls share this info. Join us and support your favorites! See you soon. 
--
2283-We accept Tc and cash only
2284-
2285:🛅 Las Escadas Pickleball will provide lockers for players ( No  extra fee) , pls take your own lock and keep your things in a safe place. Keep the chairs and tables free of belongings .
2286-
2287-🐶 Pets not allowed in the courts. It should be supervised and with leash all the time. Acces to Codominiums is restricted
2288-
2289-Pls share this info. Join us and support your favorites! See you soon. 
--
2680-🧃 Bar will be open. You may bring in your own thermos, but not packaged products. No food and drinks allowed in the complex
2681-
2682:🛅 Las Escadas Pickleball will provide lockers for players ( No  extra fee) , pls take your own lock and keep your things in a safe place. Keep the chairs and tables free of belongings .
2683-
2684-🐶 Pets not allowed in the courts. It should be supervised and with leash all the time. Acces to Codominiums is restricted
2685-
2686-Pls share this info. Join us and support your favorites! See you soon. 
--
2701-🧃 Bar will be open. You may bring in your own thermos, but not packaged products. No food and drinks allowed in the complex
2702-
2703:🛅 Las Escadas Pickleball will provide lockers for players ( No  extra fee) , pls take your own lock and keep your things in a safe place. Keep the chairs and tables free of belongings .
2704-
2705-🐶 Pets not allowed in the courts. It should be supervised and with leash all the time. Acces to Codominiums is restricted
2706-
2707-Pls share this info. Join us and support your favorites! See you soon. 
--
3320-[2026-03-05 13:17] [RECV] Palermo & Friends Buy and Sell: privately messaged you
3321-[2026-03-05 13:15] [RECV] Palermo & Friends Buy and Sell: Good day! 
3322:Looking for a small table and chairs :)
3323-[2026-03-05 10:16] [RECV] +1 (416) 834-4157: Chica you’re coming this morning, I wanted to buy balls from you… can you bring some for me? I’d say 5 😁
3324:[2026-03-05 04:56] [RECV] Palermo & Friends Buy and Sell: Hi Tamar..  It would be great if your brother can deliver the insoles.. may I have his address to send the insoles which will arrive by courier next week. to his place in Ontario?
3325-[2026-03-05 03:17] [RECV] Palermo & Friends Buy and Sell: Yes I have brand new hand blender 4 in 1
3326-[2026-03-05 02:31] [RECV] Palermo & Friends Buy and Sell: Hi there! 
3327-
3328-Looking for a hot plate - non coil 
--
4205-[2026-02-28 14:15] [RECV] +505 7859 1629: Buenos días
4206-[2026-02-28 14:15] [RECV] +505 7859 1629: Va a necesitar vegetales y frutas
4207:[2026-02-28 13:43] [SENT] Medwyn Blazer: eth address - 0xA23CC8f1Be0Cda56CD5BECe043E664Cc3b05325a
4208-[2026-02-28 13:29] [RECV] Michele: Bahahahaha
4209-[2026-02-28 13:29] [RECV] Michele: Are you preparing for our date?
4210-[2026-02-28 13:16] [RECV] Michele: Awww 🥰 - see I fuckn forgot it’s next week- heading to town in roughly an hour- let’s meet for a date- 😝
4211-[2026-02-28 13:14] [SENT] Michele: Its on Friday. We can meet. Im free anytime
--
4311-
4312-[CHORUS — the only chorus, sung once, all voices]
4313:We came from seventeen regions / with seventeen rhythms / in seventeen time
4314:We found the same signal / in seventeen languages / in seventeen time
4315-Three against four against six against five against seven / against eleven against eight
4316-Every rhythm agreed / at 336 / it is not a number — it is a state
4317-
4318-STOP AT 336
--
4416-[2026-02-26 17:17] [RECV] 🧋Teen gathering events SJDS: Ah fab sounds like there are lots of teens around. We will come along to majagual on Sunday.
4417-[2026-02-26 16:46] [RECV] Palermo & Friends Buy and Sell: 4 sets available. $550 per set (paid $650), buy 2 sets for $1,000.
4418:[2026-02-26 16:43] [RECV] Palermo & Friends Buy and Sell: Wooden table and 4 matching chairs.
4419-Table dinensions: 145 cm (57 inches) long x 74 cm (29 inches) wide
4420-[2026-02-26 16:43] [RECV] Palermo & Friends Buy and Sell: As you all may know from my posts this morning, I am desperately trying to raise money for Mickey the monkey (and money to feed the other over 100 animals in our sanctuary this week). So i am selling off some things to get the money together:
4421-[2026-02-26 16:36] [RECV] 🧋Teen gathering events SJDS: Follow this link to join my WhatsApp group: https://chat.whatsapp.com/HBXBKooWCq3BNozNT6Tapx?mode=gi_t
4422-[2026-02-26 16:35] [RECV] Michele: Tag - your it
--
4469-[2026-02-26 14:22] [RECV] 🧋Teen gathering events SJDS: Hi Katie, we also have two teens aged 13 and 14, turning 14 and 15 this March and April. Our son and our daughter  would like to join  a teen meet up, too since they are doing online school and on top we have just arrived a few weeks ago for long term stay. 😊 We are currently at Playa el Coco, but are willing to travel as well!
4470-[2026-02-26 14:12] [RECV] 🧋Teen gathering events SJDS: We are in escamequita- but can travel.
4471:[2026-02-26 14:11] [RECV] 🧋Teen gathering events SJDS: Hi all. My names Katie and we’ve been in the area for a couple of months now. I’m wondering if there are any older teen meet ups or if we could arrange something so my 17 year old son can meet some others teens. Are there many other kids similar age? I also have a 14 year old daughter (and 6,8 and 10year olds). Xx
4472-[2026-02-26 12:55] [RECV] Australia McIvor: Australian Dollar
4473-
4474-Beneficiary
4475-Corey McIvor
--
4481-772772
4482-
4483:Bank Name and Address
4484-Revolut Payments Australia Pty Ltd 
4485-Level 28, 161 Castlereagh Street, 2000, Sydney, NSW, Australia
4486-[2026-02-26 12:42] [SENT] Jose: Coming at 7
4487-[2026-02-26 12:28] [RECV] Australia McIvor: Australian Dollar
--
4496-772772
4497-
4498:Bank Name and Address
4499-Revolut Payments Australia Pty Ltd 
4500-Level 28, 161 Castlereagh Street, 2000, Sydney, NSW, Australia
4501-[2026-02-26 12:27] [RECV] Michele: No worries 😉- play hard
4502-[2026-02-26 12:12] [SENT] Michele: Yes it was really relaxing. Johanna worked the party so I had a chance to enjoy myself and not cook!!!! Nice for a change
--
5617-[2026-02-19 23:11] [RECV] Palermo & Friends Buy and Sell: Yours!
5618-[2026-02-19 22:57] [RECV] Palermo & Friends Buy and Sell: would love them
5619:[2026-02-19 22:29] [RECV] Palermo & Friends Buy and Sell: Hey everyone, anyone selling wooden furniture ? Dresser or alike to store clothing ?
5620-[2026-02-19 22:21] [SENT] Michele: I never remember her name  either
5621-[2026-02-19 22:21] [SENT] Michele: Charlie
5622-[2026-02-19 22:18] [RECV] Michele: One more time- what’s the Australian ladies name on the beach down here
5623-[2026-02-19 22:15] [RECV] Corey & Michelle House Hunting: Sure!
--
6350-[2026-02-11 17:28] [RECV] Palermo & Friends Buy and Sell: I check on google about the technical features
6351-[2026-02-11 17:24] [RECV] Palermo & Friends Buy and Sell: I'd like to buy the flour please if it's still available 💙💙
6352:[2026-02-11 16:58] [RECV] Corey & Michelle House Hunting: Corey I emailed you a bill from Hostinger that was sent to my natalitasullivan@gmail email address however when I went on their website to look at the subscriptions, I don't have any?????
6353-[2026-02-11 16:57] [RECV] Corey & Michelle House Hunting: Good morning
6354-[2026-02-11 16:53] [RECV] Gamespot And More Juarro: Ok
6355-[2026-02-11 16:53] [RECV] Gamespot And More Juarro: Gracias por comunicarte con Gamespot And More Juarro. Estamos ubicados frente al centro de salud San Juan del sur. 
6356-
--
6736-[2026-02-07 15:46] [RECV] Palermo & Friends Buy and Sell: I told you I wanted to stop payment.
6737-[2026-02-07 15:24] [RECV] Palermo & Friends Buy and Sell: Looking for small wooden desk for a kids(boy) room
6738:[2026-02-07 15:11] [RECV] Palermo & Friends Buy and Sell: Anyone selling wooden cabinets or a small dresser or something of that sort?
6739-[2026-02-07 15:08] [RECV] Official Pickleball LAS ESCADAS  info Group: Last spots available !!🏓🏓🏓🏓
6740-[2026-02-07 14:20] [RECV] Official Pickleball LAS ESCADAS  info Group: Die hards!! Love it! 😁
6741-[2026-02-07 14:14] [RECV] Palermo & Friends Buy and Sell: I do!
6742-[2026-02-07 14:05] [RECV] Official Pickleball LAS ESCADAS  info Group: Ok, see you there
--
6755-[2026-02-07 00:58] [RECV] Palermo & Friends Buy and Sell: yes
6756-[2026-02-07 00:54] [RECV] Palermo & Friends Buy and Sell: Is that glass?
6757:[2026-02-07 00:49] [RECV] Palermo & Friends Buy and Sell: Hi everyone! Anyone selling a dresser or knows where to buy one cheap? Just for a few months 👌🏻 thank you and have a great Friday !
