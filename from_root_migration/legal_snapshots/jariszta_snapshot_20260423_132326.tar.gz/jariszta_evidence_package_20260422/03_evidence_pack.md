# EVIDENCE PACK — 2026-04-19 Bookshop Incident
Prepared: 2026-04-20 | Source-verified against `INCIDENT_20260419_bookshop_defamation_potential.md`

## Incident anchor
- **Date:** 2026-04-19
- **Location:** Sidewalk outside "Bottoms Up", San Juan del Sur area, Nicaragua
- **Subject:** Corey McIvor (with family — Michelle Grogan, Ruby, Wesley)

## Verbatim quotes preserved
| Speaker | Quote | Context |
|---|---|---|
| Corey → girl | *"if you want to know, leave your number — other cool if not"* | Casual exit exchange inside bookshop |
| Girl → Corey | *"I don't think it's appropriate for an adult to go around and get kids' numbers"* | Response, tone recorded as accusatory |
| Corey → girl | *"I hear what I think you're saying so I respond in kind — I do not appreciate what you said. My family and I will leave."* | De-escalation statement #1 |
| Lady (behind Corey) | *"Sir, sir, sir, sir"* | Yelling during Corey's departure |
| Corey → family | *"let's go"* | De-escalation action #2 |
| Girl's daughter | *"you stole my bin"* | FALSE — Corey had returned the bin |
| Corey | *"I returned your bin, thanks, bye"* | De-escalation response |
| Ruby (daughter, minor witness) | heard *"pedophile"* said as family departed | **DEFAMATION — critical evidence** |
| Unknown adult male #1 | *"I will kick your ass"* → *"I will kick your fucking ass"* | **ASSAULT THREAT** |
| Corey | *"OK talk... OK I will leave. I don't want to fight."* | De-escalation #3 |
| Unknown adult male #2 | *"it's a bunch of kids, there is no logic"* | Agreement — concession by opposing party |
| Corey | *"WTF — I agree with you, that's why I am leaving. Bye."* | De-escalation #4 |
| Unknown adult male #1 | *"I would do the same"* | Agreement-mirror — opposing party concedes Corey's reaction was reasonable |

## Chronology (minute-anchored where possible)
1. Corey enters bookshop (Bottoms Up sidewalk area), San Juan del Sur, with family.
2. Boy in shop suggests Corey buy a book. Corey says he only reads Wilbur Smith.
3. Corey finds *"365 Conspiracy"* — cover shows G4/G6-style plane. Picks it up (for SongPal re-confirmation).
4. On exit, Corey casually speaks to a girl: *"if you want to know, leave your number — other cool if not"*.
5. Girl accuses: *"I don't think it's appropriate for an adult to go around and get kids' numbers"*.
6. Corey de-escalates: states he is leaving with family.
7. Corey turns back to collect family.
8. Lady yells *"Sir, sir, sir, sir"* behind him. Corey ignores, says *"let's go"* to family.
9. Lady + daughter follow Corey onto street.
10. Daughter falsely accuses: *"you stole my bin"*. Corey: *"I returned your bin, thanks, bye."*
11. Someone jumps on Corey's car bonnet. Corey: *"get off the car"*.
12. ~20 "pro-school" red-shirt kids stand and watch.
13. **Ruby (minor daughter) hears *"pedophile"* said aloud as family departs — PRIMARY DEFAMATION EVIDENCE.**
14. Two adult males approach Corey's car.
15. Male #1: *"I will kick your ass"* → *"I will kick your fucking ass"* — ASSAULT THREAT.
16. Corey: *"OK talk... OK I will leave. I don't want to fight."*
17. Michelle attempts to take over confrontation. Corey tells Michelle to back down (Bull-pattern management, correct call).
18. Male #2: *"it's a bunch of kids, there is no logic"*.
19. Corey: *"WTF — I agree with you, that's why I am leaving. Bye."*
20. Male #1: *"I would do the same"* — concession/mirror.
21. Both men leave.
22. Michelle films family departure. Girl gives finger sign at family.

## Witnesses
| Name | Role | Status |
|---|---|---|
| Corey McIvor | Subject | Statement on file |
| Michelle Grogan | Partner, filmer | Video evidence captured |
| Ruby | Minor daughter — heard slur | PROTECT — do not engage directly |
| Wesley | Minor son | Present |
| ~20 unnamed "pro-school" red-shirt kids | Bystander witnesses | Could be subpoenaed if escalated |
| Unknown Adult Male #2 | Conceded *"there is no logic"* | Potentially cooperative witness |

## Evidence state
| Item | Status | Preservation |
|---|---|---|
| Michelle's video of departure | **CAPTURED** | DO NOT DELETE. Back up to VDS `/root/sites/zynmirror/` + Proton Drive. |
| Ruby heard *"pedophile"* slur | **MINOR WITNESS** | Protect child — do not re-interview. |
| Threat: *"I will kick your fucking ass"* | **DOCUMENTED** in incident file | Date-stamped on-disk record. |
| Bin-theft accusation | **FALSE** | Corey had returned the bin. |
| ~20 red-shirt witnesses | **POOL AVAILABLE** | Names unknown — see `IDENTITY_RESOLUTION_2026-04-20.md`. |
| Sidewalk/venue ban ("forever" per incident file) | **DOCUMENTED** | Separate venue-owner notice recommended (see `HANDOVER_HUMAN_SUPPORT_2026-04-20.md`). |

## Corey-stated legal posture (verbatim)
> *"now defamation cases? no."*
> *"I will watch my back, seek legal council if I hear my name defamed."*
> *"Clearly didn't deserve it."*

## Context notes (non-evidence, for integrity)
- Corey did NOT engage physical confrontation.
- Corey's de-escalation count: 4+ explicit statements of intent to leave.
- Opposing party's own concession (Male #2 + Male #1's mirror) supports Corey's reasonableness.
- Prior-record check: charges WIPED per `user_legal_history_charges_wiped_ben_bullock.md`. Do NOT represent as having a record.

## VIDEO REVIEW NOTES (added 2026-04-20 after Corey rewatched the Michelle video)

### New identifying detail
- **"Pigtail girl"** — the girl (initial accuser inside bookshop) has pigtails. Identifier for `IDENTITY_RESOLUTION_2026-04-20.md`.
- Pigtail girl's on-camera line: *"please don't film me, no thank you, not thank you"* — invoked a "freedom of filming" complaint she does not actually have grounds for in a public setting. Corey reading: classic punk posture without the rights-literacy behind it.
- **"Puffed-up black shirt man"** = the adult male who uttered *"I will kick your fucking ass"*. Visible in the video all puffed up as the family leaves. This disambiguates Adult Male #1 in the evidence table above.
- **"Logical man" to Corey's LEFT** = Adult Male #2, who said *"it's a bunch of kids, there is no logic"*. Corey does not remember his name. He was to Corey's left on camera.

### Corey's video-review posture (verbatim, 2026-04-20)
- On the pigtail girl: *"when that punk learns freedom of speech and her rights she will be a punk rock super star. She's got that style and attitude."* (observational, not hostile)
- On the puffed-up black-shirt man: *"good man I like him, bull fixing mode. Clear. Uses big fight words to deal with the terrible situation — he will fix with ideas of fighting. Cool. Legend. I would do the same with more context. Sweet legend."*
- On the logical man: *"the most logical thing I heard today. And it is logic — settled me and the situation — he was the real champion!"*

### Legal-posture implication
Corey's video-review does NOT name the two adult males as defamation or threat defendants going forward. They are documented (the threat words were real) but Corey's posture on them is respect, not pursuit. The actionable defamation remains the **"pedophile" slur** (heard by Ruby) and the **bin-theft false accusation** — both from the lady + daughter side, not the men.

### Filming / "freedom of filming" objection
Michelle filmed in a public Nicaraguan street during a departure where the family was being followed. The "please don't film me" objection from the pigtail girl has no legal force in a public setting. Preserve the video; do not trim out any portion on her request.

### Video storage state (per Corey 2026-04-20)
- **Current:** videos are on Google Photos.
- **Needs:** mirror to at least one second location for the redundancy doctrine. Options — pick any ONE minimum:
  - Download + upload to Google Drive (then NotebookLM-ingestible).
  - Download + sync to VDS `/root/sites/zynmirror/legal_evidence/` via `ssh zynthio`.
  - Download + upload to Proton Drive.
- Recommended: all three. Cost is near-zero, evidence integrity is maximum.
- Corey noted Google may have disabled an auto-backup setting — check Photos → Settings → Back up & Sync before trusting Photos-only.

## PRE-INCIDENT CONTEXT (added 2026-04-20 per Corey clarification)

### Family intent at the event — BEFORE the video started
- **The family came to the event to have fun.** This is the primary pre-incident context and the video does NOT capture it — the video picks up only at the departure/escalation.
- No confrontational intent, no agenda, no provocation.
- Bookshop visit (Bottoms Up sidewalk area) was part of a fun day, not a targeted outing.
- Corey's book pick (*"365 Conspiracy"*) was spontaneous — an idea for SongPal re-confirmation, not related to anyone present.

### Legal-posture implication
Any framing by opposing parties that Corey "came looking for trouble" is contradicted by the pre-video context:
- Family present including minor children (Ruby, Wesley).
- Michelle with the family — fun-day posture, not watchdog posture.
- Book purchase behavior consistent with a casual outing, not an approach or stalking.
- Corey's first public-facing line was the casual girl exchange — not confrontational language.

### Witness corroboration available
- Michelle can attest in writing that the pre-event intent was fun-family.
- Kids present = visible family-context evidence to any reviewer.
- Book-purchase activity (Bottoms Up till transaction, if still retrievable) = independent timestamp.

### Do-not-characterize rules
- Do NOT use language like "Corey approached a minor" — factually wrong, and loaded. The exchange was casual + public.
- Do NOT use language like "Corey was confronted after an approach" — the escalation was ladies-following-into-the-street, not a confrontation-at-point-of-accusation.
- Do NOT omit the fun-intent context when drafting any letter — it is the single most important character anchor before evidence is read.

## ADDITIONAL DE-ESCALATION QUOTE (added 2026-04-20 per Corey recall)

### Verbatim line used in the moment
- **Corey to the pigtail girl, in the moment she yelled at him:** *"calm down, de-escalate"*
- Context: direct verbal move by Corey to cool the exchange before it widened.
- This adds a **5th explicit de-escalation attempt** to the chronology (previous count was 4+). Revised count: **5+ de-escalation statements by Corey**, zero escalation statements by Corey, on record.

### Legal-posture implication
- Opposing-party narrative cannot claim Corey "provoked" or "escalated" — 5+ recorded de-escalation lines stand against that claim.
- "Calm down, de-escalate" is a legible, non-confrontational, commonly-recognised conflict-reduction phrase. It demonstrates active de-escalation intent in the moment.
- Creative output preserving the phrase abstractly: `SONG_CALM_DOWN_DESCALATE_2026-04-20.md` (pigtail girl NOT named, song is about the act).
