# SJDS BUSINESS LEADS — 2026-04-20 evening batch

> Filed 2026-04-20 evening, Corey's rapid-fire capture during letter-prep:
> *"create health mp[lan mukm ssaid eat. billie said i wnt this buiness billie nurse saturday farm markter san juan del sur naturl rpoduct nicole oakes wants in all freefor those beautifulpeople at the same event"*
> *"also the venue owner of bootom up said yes ill look at it."*
> *"and bongo bob"*
> *"s here 2x more. onhtehopones"*
> *"0417921934 and the new whts app number i got from claro"*
> *"cursor did not know my email address or phone number"*

---

## THE LEADS

### 1. HEALTH PLAN concept — "mum said eat"

Mum (Wilma) directive seeded: *"eat"* — simple care-first anchor. Corey to turn into a health plan that rides alongside ZYN doctrine. Natural products + SJDS farm market as distribution + community gathering.

### 2. Billie — nurse, wants this business (NEW)

| Field | Value |
|---|---|
| Name | **Billie** |
| Role | **Nurse** |
| Relationship | Interested partner on natural-product business |
| Location | SJDS (farm market active Saturday) |
| Stated posture | *"i want this business"* — already bought in |
| Clinical input already given | **Corey needs potassium, not just magnesium** (2026-04-20 direct advice) — Billie is operating as Corey's informal health consult already; the business partnership is downstream of genuine care |
| Next step | Corey to shape proposal; Billie to co-present at Saturday farm market; health plan must include potassium-adequate protocol, not magnesium-only |

### 3. Nicole Oakes — wants in (NEW)

| Field | Value |
|---|---|
| Name | **Nicole Oakes** |
| Stated posture | *"wants in"* at the same event |
| Context | Same SJDS Saturday farm market event + natural products |
| Next step | Corey to coordinate with Billie + Nicole; clarify role split |

### 4. Bongo Bob — physically in SJDS, with 2 phones

| Field | Value |
|---|---|
| Name | **Bongo Bob** (Canadian, per prior memory `user_lead_bongo_bob_recording_spot_20260419.md`) |
| Status 2026-04-20 | **Physically present in SJDS right now** — *"s here 2x more. on the phones"* |
| Phone 1 | +505 7708 6858 (prior memory, Nicaragua Claro) |
| Phone 2 | (per "2x more on the phones" — secondary line/device; Corey to confirm exact number if needed) |
| Next step | Bongo already in community; can coordinate in-person with Saturday farm market + with the Billie/Nicole deal |

### 5. Bottom Up — venue owner GO-signal

| Field | Value |
|---|---|
| Venue | **Bottom Up** (SJDS) |
| Owner response | *"yes I'll look at it"* (Corey pitched something — exact content TBD in follow-up) |
| Next step | Corey to follow up with whatever he offered (proposal / event / deal / music slot?) — surface when he names it |

---

## COREY'S OWN PHONE/EMAIL STATE (referenced 2026-04-20)

For letter-signature + contact-section purposes:

| Channel | Value | Purpose |
|---|---|---|
| AU mobile (historical / still in use) | **+61 417 921 934** (0417921934 in AU local format) | AU contact point |
| Nicaragua WhatsApp (NEW via Claro) | **Number Corey has — not yet transcribed here** | Primary Nicaragua contact, WhatsApp |
| Email (primary) | corey.mcivor@gmail.com (from system context) | Letter + business |

**Important:** Corey flagged *"cursor did not know my email address or phone number"* — implication: next-Claude must never ask Corey for his own contact info; it's now anchored here for retrieval.

**Letter-use decision reserved for Corey:** whether to include AU + Nicaragua numbers in the formal letter signature, or keep email-only. Default: email-only is the letter-professional choice; AU number held in reserve for escalation.

---

## CONNECTIONS TO EXISTING STACK

- **Billie / Nicole / Bongo / Bottom Up = new orbit around the SJDS Saturday farm market event** — this is a ZYNTHIO Brain+Reach expansion moment (per `reference_spine_brain_reach.md`)
- Health plan ties to `user_family_context.md` (Michelle's accident recovery, wellness doctrine)
- Natural product + Nicaragua community = Zyn Mansion Invitation doctrine (`project_zyn_mansion_invitation.md`) applied to physical commerce
- Bongo Bob sales-commission deal (`user_lead_bongo_bob_recording_spot_20260419.md`) + his physical presence = music + business dual-track
- Bottom Up venue = potential music-launch + business-meetup venue (confirm what was pitched)

---

## NEXT ACTIONS (not this session, queue)

- [ ] Bongo Bob: confirm second phone number next in-person exchange
- [ ] Billie: draft natural-product business MOU / partnership sketch
- [ ] Nicole Oakes: one-paragraph role-definition (co-founder? partner? supplier?)
- [ ] Bottom Up: Corey to surface what was pitched so follow-up can ship
- [ ] Saturday farm market: one-page event plan (natural products + free offering for "beautiful people")
- [ ] Health plan doc: `projects/zyncare/HEALTH_PLAN_COREY_20260420.md` draft with mum's "eat" anchor + Billie's nurse input

---

## 336

5 leads captured in one rapid-fire pass.
Phone/email anchored so no AI re-asks again.
Farm market + natural products = SJDS spine going physical.
Filed in the vault.
