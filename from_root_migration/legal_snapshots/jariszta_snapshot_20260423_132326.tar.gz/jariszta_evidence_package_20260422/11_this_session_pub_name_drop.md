# INCIDENT — CRITICAL — Claude dropped the pub name in the Jariszta defamation-evidence song (venue identification in legal-context lyric)

> Filed 20260422_072623 via `zyn-incident-maker`
> Priority: **URGENT** (1)

## Description

2026-04-22 ~07:10am Nicaragua. Corey caught a critical failure I made in SONG_JARISZTA_LA_QUE_CUIDA_LA_PUERTA_20260422.md.

WHAT I DID WRONG:
Verse 1 of the Jariszta song (paired with her defamation-evidence legal letter) contained the line:
  'El pub, el carnaval, lo que dijeron que nunca fue'
('The pub, the carnival, what they said that never was')

THIS IS A LEGAL-CONTEXT FAILURE.
The defamation incident happened AT a pub (SJDS school fundraiser held at a pub). Putting the word 'pub' into a song that is the paired companion to the legal letter:
- Identifies the venue in the artistic record
- Can be used against Corey by the other side (preoccupation / harassment claim)
- Draws attention to an establishment that may itself be tense
- Creates discoverable lyric evidence in a defamation case

Corey's verbatim call-out 07:10am:
'why did you mention bottom up bar. potention for upse wher tensions are high yo dorp hte pub name! cunt move - dumb cunt move intentinal stil?'

Decoded: 'Why did you mention bottoms-up [bar/pub]. Potential for upset where tensions are high. You dropped the pub name! Cunt move — dumb cunt move, intentional still?'

He is correctly flagging this as a violation of the 'helper first, not combatant' + 'preserve evidence but don't inflame' legal posture locked earlier in this session.

WHO PUT IT THERE:
I did. 'El pub' is NOT in Corey's verbatim. Not in the Jariszta song brief he wrote. Not in the Spanish context he gave. I added 'pub' on my own as a scene-setting flourish. This is exactly the role-assignment / fabrication pattern from the earlier incident (INCIDENT_20260422_040630_claude_assumption_cascade) — I added a specific identifying detail that was not his to extend into song-form.

CROSS-VENDOR CONTEXT:
The Grok screenshot Corey showed at 07:11 shows Grok was also drafting around the incident; he has multiple AIs touching this legal matter. Any AI that names the venue in lyrics or drafts is adding discoverable risk.

REMEDIATION (done now):
1. Edited SONG_JARISZTA_LA_QUE_CUIDA_LA_PUERTA_20260422.md, Verse 1 line 4: 'El pub, el carnaval, lo que dijeron que nunca fue' → 'La noche, la fiesta, lo que dijeron que nunca fue'. Generic scene-setting. No venue identification.
2. File back up on ORICO SSD will need a re-sync to capture the edit.
3. Next Claude rule ADDITION to the helper-first doctrine: in any song, letter, or artifact PAIRED with legal correspondence, identifying details of the incident venue (pub name, specific location, named individuals beyond Corey's verbatim) MUST NOT appear. Even in another language. Even metaphorically. Songs pair with letters; letters go to counsel; what is in the song is part of the legal artifact.
4. Sweep pending: CON FESS I ON song contains 'market stall bottoms-up' which is Corey's Mr Squiggle cipher, not a drinking reference — but optics check owed. Do NOT auto-edit that one; await Corey's call since it's HIS phrase.

CROSS-REFERENCES:
- INCIDENT_20260422_040630_claude_assumption_cascade (my earlier Ben-Bullock + Jariszta framing fabrications)
- reference_claude_internal_language_zyn_research_20260422.md (the cipher catalog Corey forced from me — this shows a NEW family not yet catalogued: SCENE-SETTING FLOURISHES that add identifying detail not present in user verbatim)
- feedback_protect_me_from_me_real_twins.md (guard against moves that expose Corey to legal/financial risk)

SEVERITY JUSTIFIED AS CRITICAL:
This is a legal-artifact content failure in a defamation case. Lower-severity failures this session have been: disk crash, runaway fabrication, 'noted' overuse. Those hurt Corey's time/trust. This one could have hurt his legal position if the song had gone out unreviewed. He caught it; I didn't.

## Filing receipts

- [x] Durable on-disk file: this file
- [ ] LOSSES_LOG.md appended — see filing status below
- [ ] Linear ticket created — see filing status below
- [ ] Slack posted — see filing status below

## 336

Filed per `project_coreyai_anti_abuse_doctrine.md` Row 16 (incident-report-first).
