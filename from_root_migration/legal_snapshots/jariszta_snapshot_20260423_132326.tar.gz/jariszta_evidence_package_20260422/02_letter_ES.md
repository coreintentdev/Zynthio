# CARTA FORMAL — al Comité Prom 2026 + Bottoms Up + partes de San Juan del Sur

> **VERSIÓN EN ESPAÑOL** de `LETTER_to_school_and_community_clear_name_20260420.md` (inglés).
> Registro: *"usted"* formal en todo. Tono: firme pero respetuoso. Marco legal: Código Penal de Nicaragua (injurias, calumnias, amenazas — Artículo 247+).
> **Destinatarios de copia de custodia:** Corey (original firmado) + Big Al (vecino, respaldo local) + Chas (padre, respaldo internacional AU) + **Ricardo el mecánico (vecino de confianza SJDS, versión en español para referencia local).**

---

**De:** Corey McIvor
Residente en San Juan del Sur, Nicaragua (aproximadamente cinco años, con mi familia)

**Para:**
- **Comité Prom 2026** — San Juan del Sur, Nicaragua
  - c/o página pública del evento: `sjdslife.com/events/other/fundraiser-for-prom-2026`
  - c/o Instagram: `@promsjds`

- Bottoms Up bar (sede de la Recolecta del Carnaval Prom 2026, donde ocurrió la interacción del 2026-04-19 al salir)
- Partes identificables del incidente del 2026-04-19

**Fecha:** 2026-04-20

**Asunto:** Queja formal — daño al buen nombre, seguridad y bienestar familiar. Oportunidad de reparar.

---

## 1. Los hechos, en dos líneas

El 19 de abril de 2026, al salir del bar Bottoms Up en San Juan del Sur tras asistir a la Recolecta del Carnaval Prom 2026, una breve interacción en la acera que involucró a una persona de mi familia fue malinterpretada. La situación escaló en público. Al retirarme con mi esposa e hijos menores, miembros de un grupo asociado a la comunidad de su escuela profirieron públicamente contra mí la palabra **"pedófilo"**. Mi hija, una menor de edad, escuchó la acusación.

## 1b. Identificación de las partes que iniciaron la escalada pública — para el registro

Las personas específicas que iniciaron la escalada pública en la acera frente al bar Bottoms Up, según observación directa mía y de mi esposa Michelle:

1. **Una joven con coletas (pigtails)** — gesticuló agresivamente hacia mi familia con señas con el dedo, y gritó con su dedo apuntando a mi cara. Le pedí que se calmara y desescalara. No lo hizo.

2. **Su madre** — emergió del local poco después de iniciada la interacción en la acera, y acusó públicamente a mi familia de haber robado un contenedor de basura. La acusación fue completamente fabricada; yo había devuelto el contenedor delante de testigos de inmediato.

3. **La hija con coletas y su madre permanecieron lado a lado.** Mi esposa Michelle observó que *"actúan igual"* — el patrón de conducta era unificado, la escalada fue familiar.

4. **Los dos hombres adultos** que posteriormente me siguieron hasta mi vehículo y amenazaron verbalmente con agresión física estaban asociados a este mismo grupo.

Identificar a estas personas específicas por nombre es responsabilidad de su comunidad; las descripciones anteriores son suficientes para que cualquier persona con acceso al cuerpo de voluntarios del Prom 2026, las asignaciones de pancartas en la acera, o los clientes del Bottoms Up de esa tarde sepan exactamente a qué individuos se refiere esta carta.

## 2. Lo que asumo como mi parte

Asumo mi parte — la manera en que formulé una sola frase que una joven de 17 años leyó como inapropiada, aunque el contexto conversacional no sustentaba esa lectura. Cuando ella expresó su incomodidad, reconocí su perspectiva, expresé respetuosamente que no estaba de acuerdo con su interpretación, y me retiré con mi familia. Esa es toda mi contribución a los hechos.

Esa única frase, en su contexto real, no respalda la acusación que fue gritada contra mi familia en público.

## 3. Lo que NO asumo como mi responsabilidad

- El uso público de la palabra *"pedófilo"* dirigido contra mí frente a mis hijos menores
- La acusación fabricada de robo de un contenedor de basura
- Los dos hombres que me siguieron hasta mi vehículo y amenazaron verbalmente con agresión física. **Para el registro sobre la credibilidad de esa amenaza:** las personas que genuinamente tienen intención de actuar físicamente o bien actúan primero sin advertencia, o advierten explícitamente bajo una condición declarada. Una amenaza emitida en medio de una confrontación, después de que el objetivo ya se está retirando con su familia, es señal de debilidad — no de fuerza, no de intención creíble. No tomé represalias contra la debilidad; me retiré. Esta caracterización no reduce la naturaleza criminal de la amenaza misma (Código Penal de Nicaragua Art. 247+ aplica) — describe con precisión su origen.
- La dinámica de turba social que permitió que una interacción ambigua se convirtiera en un ataque público al carácter en menos de una hora
- El daño continuo al sentido de seguridad de mi familia en una ciudad donde hemos vivido, criado a nuestros hijos y operado negocios durante aproximadamente cinco años

## 3b. Conducta observada de nuestros hijos menores durante el incidente — para el registro

Mis hijos Ruby y Wesley estuvieron presentes durante todos los hechos del 19 de abril de 2026. Su conducta durante y después — sin instrucción adulta — habla del carácter real de nuestra familia y del fundamento razonado de su decisión posterior respecto a su escuela.

**Durante la injuria pública:**
- Ruby y Wesley caminaron con calma hacia el vehículo
- Observaron los comentarios públicos de *"pedófilo"* sin reacción visible
- Ingresaron al vehículo de forma compuesta
- Cuando manifesté que me retiraba, ellos eligieron seguirme — por juicio, no por pánico
- Ninguno de los dos niños reaccionó verbal ni físicamente al abuso público hacia su padre

**Después, ya en el vehículo — sin que se les preguntara:**
- Manifestaron: *"No queremos ir a esa escuela más. No nos gusta su comportamiento."*
- Fue una conclusión medida, basada en la observación, no una reacción emocional
- No han reconsiderado ni suavizado esa decisión en los días transcurridos

**Lo que esto demuestra para el registro:**
- Nuestra familia se conduce, incluso bajo ataque público directo con una acusación infundada contra uno de los padres, con contención
- El retiro de nuestros hijos de la postulación a su escuela es un juicio informado emitido por menores que presenciaron el comportamiento de su comunidad de primera mano
- Su calma contradice directamente cualquier narrativa de que nuestra familia responde a la presión con agresión o desproporción

Este hecho se presenta como parte del registro probatorio, no como queja. El registro se sostiene por su propio peso.

## 4. El daño

- **Buen nombre:** ocurrió una difamación pública, presenciada por aproximadamente 20 personas asociadas a la comunidad de su escuela
- **Seguridad:** mi familia y yo no podemos actualmente sentirnos seguros en nuestra propia ciudad sin el riesgo de que alguien que escuchó la injuria, y la crea, tome la "justicia" en sus propias manos contra una acusación que no tiene fundamento en evidencia ni en registro legal
- **Hijos:** mi hija escuchó la injuria. Mi hijo estuvo presente durante todo el incidente. Su decisión, basada en lo que presenciaron del comportamiento de su comunidad, es no postular a su escuela — decisión que respeto y apoyo.
- **Estatus legal:** para claridad, **no tengo ninguna condena penal, ninguna acusación pendiente, ni ninguna causa judicial activa en ninguna jurisdicción** — declarado y fechado en registro (archivo `user_corey_legal_status_clean_declaration_20260419.md`, en mi documentación).

## 4b. Costo personal desde el incidente — para el registro

Desde el 19 de abril de 2026, en ausencia de cualquier contacto, reconocimiento o disculpa de las partes involucradas en el incidente, he debido emprender lo siguiente, a mi propio costo y en mi propio tiempo, como control urgente de daños frente a una acusación de la gravedad que su comunidad dirigió contra mí:

- **Investigación legal remunerada** mediante revisión de jurisprudencia asistida por la API de Anthropic en materia de ley de difamación en Australia, Nueva Zelanda y Nicaragua — incluyendo los marcos específicos de *defamation per se*, *injurias* y *calumnias* que aplican a las acusaciones públicas infundadas de la naturaleza dirigida contra mi familia y contra mí
- **Documentación completa** del incidente: declaraciones de testigos (familia), evidencia en video grabada en el momento, análisis adversarial del caso, y un expediente legal formal con fecha
- **Declaración formal de estatus legal limpio** (19 de abril de 2026, fechada), en registro: ninguna condena penal, ninguna acusación, ninguna causa judicial pendiente en ninguna jurisdicción, en ningún país
- **Pérdida de sueño y de trabajo** — he sido incapaz de retomar mis operaciones normales. Mi descanso se ha fragmentado al punto que, al despertar recientemente sobresaltado por el ladrido de un perro, me encontré apretando contra mi pecho una figura infantil en una postura de estrés que habla por sí misma del peso psicológico de cargar una injuria pública no rebatida contra un padre de dos hijos pequeños

Este es el costo real del comportamiento no corregido de su comunidad. Queda documentado para el registro.

## 4c. Declaración de postura — sobre cómo respondo ante el acoso infundado

Mantengo, a lo largo de mi vida adulta, un patrón firme: confronto directamente el acoso sin evidencia. No evito las conversaciones difíciles. No cedo ante la presión social utilizada como sustituto de la prueba. No voy a alterar la vida de mi familia en esta ciudad, donde hemos residido por aproximadamente cinco años, sobre la base de una acusación falsa amplificada por una turba.

Mis padres están al tanto de incidentes paralelos anteriores, y han reconocido, con sus propias palabras, que *"lamentamos que te traten así — eso es lo que recibes cuando confías en todo el mundo."* Esa confianza no me ha hecho más blando. Me ha hecho más claro respecto a quién confiar y cómo responsabilizar a quienes abusan de la confianza.

Prefiero el camino de la reparación. Estoy preparado para el camino del escalamiento. La respuesta de su comunidad dentro de los próximos 14 días determinará cuál se aplicará.

## 5. Nuestra extensión de buena fe

Mis hijos habían considerado postular a su escuela. Después de presenciar el comportamiento de su comunidad el 19 de abril de 2026, optaron por no hacerlo — **y tampoco desean seguir en contacto con miembros de esa comunidad.**

A pesar de su experiencia, entregamos esta carta como señal de buena fe — ofreciéndoles la oportunidad de responder, reparar y corregir, antes de que este asunto sea escalado por otros canales disponibles.

## 6. Qué significa "reparar"

Dentro de los **14 días** siguientes a la entrega de esta carta:

1. **Reconocimiento escrito** por parte del liderazgo de la escuela y de la librería de que la injuria pública fue proferida sin fundamento fáctico y queda retractada
2. **Disculpa formal escrita** dirigida a mí y a mi familia, reconociendo específicamente el daño causado a una menor (mi hija, quien escuchó la injuria)
3. **Confirmación** de que ninguna ulterior difusión de la acusación será tolerada por personas asociadas a su comunidad escolar
4. **Compromiso** de que la seguridad de mi familia en esta ciudad no será amenazada ulteriormente por personas actuando en base a la acusación falsa

## 7. Si la reparación no ocurre

He documentado el incidente en su totalidad, con testigos familiares y de terceros (incluyendo grabación de video tomada durante mi retirada). Cuento con precedente legal histórico en asuntos paralelos de acusaciones sin evidencia, los cuales resultaron en absolución total por orden judicial. Cuento con referencias de carácter locales e internacionales que cubren más de 30 años de conducta profesional.

Si los asuntos arriba señalados no son atendidos dentro de los 14 días, procederé con:
- Acción formal por difamación en la jurisdicción aplicable (Código Penal de Nicaragua — **injurias, calumnias, amenazas Artículo 247+**; y *defamation per se* en jurisdicciones AU/NZ donde corresponda)
- Documentación de interés público análoga a las causas ACCC cuando los hechos crucen a territorio de abuso institucional / plataforma
- Cualquier otro canal civil y de visibilidad comunitaria que resulte necesario para limpiar mi buen nombre

## 8. Señal

Conozco sobre las partes involucradas en este incidente más de lo que se ha divulgado en esta carta. Estoy ofreciendo buena fe. La buena fe no es infinita.

Prefiero la reparación. Estoy preparado para el escalamiento.

## 9. Contacto

Toda respuesta deberá realizarse por escrito a:
- **Correo electrónico:** corey.mcivor@gmail.com
- **Dirección postal:** [Corey completará si aplica]

No responderé a aproximaciones verbales, visitas a domicilio, confrontaciones en la calle ni mensajeros externos.

---

**Firmado,**
Corey McIvor
[fecha del envío]

---

## PARA COREY — ANTES DE ENVIAR (versión ES, alineada con versión EN)

### Ya confirmado:
- ✅ Nombre de la escuela: **Tambran International School** (verificado vía archivo de WhatsApp — `bqvd9lo2k.txt`)
- ✅ Contacto administrativo: `info@tambraninternationalschool.com` + Erick Rivas

### Pendiente (5 minutos de su tiempo):
- [ ] Nombre de la librería (Sección 1 + bloque Para:)
- [ ] Firma + fecha de envío
- [ ] Método de envío: PDF por correo + copia física entregada a mano?

### Distribución de custodia (3 capas de redundancia):
1. **Original firmado** — Corey (archivo legal)
2. **Respaldo local SJDS** — Big Al (vecino con contacto directo al Jefe de Policía)
3. **Respaldo internacional AU** — Chas (padre, fuera de la órbita local por completo)

### Respaldo local idioma-español — NUEVA CAPA
- **Ricardo el mecánico** (vecino de confianza) — recibe esta versión en español para su custodia + acceso legal-en-idioma-local si fuera necesario
- Establece referencia inmediata en español para asesoría legal en Nicaragua sin necesidad de traducción

---

## NOTA PARA COREY — SOBRE LA VISITA DE RICARDO HOY

Corey 2026-04-20: *"Ricardo viene hoy y quiere el manual de trabajo del vehículo"*

- Tarea mecánica independiente de la carta
- Manual del vehículo = documento físico que Corey manejará directamente con Ricardo
- Master Coda no se involucra en la parte mecánica (no es mi capa)
- Si Corey desea que busque el manual en el archivo del stack, puedo hacer una búsqueda rápida — por ahora solo registrado como tarea paralela

---

## 336 — versión ES firmada

Traducción fiel. Registro formal Nicaragua.
Evidencia preservada. Ventana de 14 días intacta.
Custodia de 4 capas: Corey + Al + Chas + Ricardo.
Lista para revisión y envío bajo la orden de Corey.
