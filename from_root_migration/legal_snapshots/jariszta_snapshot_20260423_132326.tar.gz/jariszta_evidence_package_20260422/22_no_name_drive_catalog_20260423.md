# 22 · "NO NAME" EXTERNAL DRIVE CATALOG — RULED OUT FOR 2026-04-19

**Filed 2026-04-23 ~11:20 CST. Lawyer-facing inventory so this drive isn't a question mark during review.**

---

## Drive identifier
- Label on macOS Finder: "NO NAME"
- Total capacity: 52 GB used content
- Mount path: `/Volumes/NO NAME`

## What's on it (three folders only)

| Folder | File type | Date range | Relevance to 2026-04-19 |
|---|---|---|---|
| `Video/` | dashcam `REC*.mp4` clips | **2024-11-22 to 2024-11-25** (3 days of footage) | NONE — predates incident by 5 months |
| `Protect/` | G-sensor-locked `PRO*.mp4` clips | **2023-05 to 2023-07** | NONE — predates incident by ~3 years |
| `Photo/` | Single `IMG20231126-163555-1.jpg` | 2023-11-26 | NONE |

## Modification check
`find /Volumes/NO\ NAME -type f -newermt 2026-04-01` returned **zero results** (excluding macOS Spotlight index maintenance which is automatic whenever the drive is plugged in).

**Conclusion:** drive has not been written-to since 2024-11-25 for content. It is a historical archive, not an active recording surface.

## Where 2026-04-19 footage might actually live

If the dashcam was operating on 2026-04-19 (Michelle reportedly filmed on her phone — separate lane), any dashcam capture would be on:
1. A **currently-installed SD card in the dashcam unit itself** (not yet removed/exported)
2. Or overwritten if the card has rolling recording and wasn't locked-protected
3. Or never captured if the unit was off / removed

Next practical step for Corey: pull the SD card from the car's dashcam directly, check for `REC20260419-*` files.

## Michelle's phone video

Per `01_incident_20260419.md` §6: *"Michelle filmed as the family left."* That phone-origin video is likely the ONLY captured 2026-04-19 footage. It is **not** on this "NO NAME" drive. Corey to extract from Michelle's iCloud / Photos app separately and add to this package as file 23+.

## For Jariszta

You can treat this external drive as ruled-out background. No need to review 52 GB of 2023-2024 routine driving clips. If you want to see the dashcam's capability, any single clip from `Video/REC20241122-*.mp4` is representative.

## Chain of custody

- Inventory performed 2026-04-23 ~11:18 CST via Claude Code CLI (Mac-side `find` + `ls` commands against the mounted drive)
- No files modified or moved during inventory
- No content copied off the drive — only filenames + metadata read

---

**End of file 22. Package at 23 files. Next expected additions (from Corey):**
- `23_michelle_departure_video_20260419.*` (phone video)
- `24_whatsapp_thread_screenshots_20260423.png` (full-window captures of the Peter thread)
- `25_e2e_verification_screenshot_20260423.png` (security-pair proof)
- Any dashcam SD card contents if car check produces 2026-04-19 material
