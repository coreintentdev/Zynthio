# Formal Notice — Defamation, Threats, and Written-Only Contact

Date: 2026-04-20

To: [Principal Name — UNRESOLVED, see `IDENTITY_RESOLUTION_2026-04-20.md`], School Administration

From:  
Corey McIvor  
Michelle Grogan

Incident anchor: 2026-04-19, sidewalk outside "Bottoms Up", San Juan del Sur area, Nicaragua
Source of truth: `INCIDENT_20260419_bookshop_defamation_potential.md` + `EVIDENCE_PACK_2026-04-20.md`

Subject: Formal Notice and Warning — False Allegations, Threats, and Safety Harm

This is a formal notice regarding false allegations, public harassment, and threatening conduct directed at Corey McIvor while he was leaving with family present.

This matter is now formal. There will be no hearsay in this process.

## Core position

1. We do not consent to unverified allegations being repeated as fact.
2. We reject rumor-based character labeling.
3. We require evidence-based handling only.
4. We require written communication only at this stage.

## Statement of incident posture

- Corey did not seek confrontation.
- Corey stated he was leaving.
- Threatening language was used toward Corey in public.
- Family members were present and witnessed events.
- Michelle witnessed and documented the departure context.

## Clarification on reaction

Corey makes no apology for reacting strongly to being publicly accused/labeled in this way.  
Any reaction must be viewed in context of immediate accusation, crowd pressure, and direct threat language while leaving.

## Formal warning

Any further repetition of unverified allegations as fact, any intimidation, or any threatening approach toward Corey, Michelle, or family members will be treated as escalation and preserved for legal action.

## Required written actions from school administration

1. Confirm receipt of this notice today.
2. Confirm in writing that staff/parents/students are not to repeat unverified allegations as facts.
3. Confirm in writing that no one is to approach, threaten, or harass Corey, Michelle, or family members.
4. Provide written prevention steps and a contact point accountable for this matter.

Please respond in writing within 48 hours.

Signed,  
Corey McIvor  
Email: corey.mcivor@gmail.com  
Phone: [insert]

Michelle Grogan  
Email: [insert confirmed email]  
Phone: [insert]
