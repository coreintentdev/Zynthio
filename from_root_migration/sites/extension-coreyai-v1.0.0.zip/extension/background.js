// CoreyAI Background Service Worker
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'SUBMIT_INCIDENT') {
    fetch('https://api.coreyai.ai/api/v1/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'User-Agent': 'CoreyAI-Extension/1.0' },
      body: JSON.stringify(msg.payload),
    })
    .then(r => r.json())
    .then(d => sendResponse({ ok: true, data: d }))
    .catch(e => sendResponse({ ok: false, error: e.message }));
    return true; // keep channel open for async
  }
});
