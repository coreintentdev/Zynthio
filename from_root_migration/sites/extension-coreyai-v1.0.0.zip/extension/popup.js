// CoreyAI Extension — Popup Logic
let currentMode = 'fail';
let pageContext = null;
let lastSnippet = '';

// ─── Init ───
document.addEventListener('DOMContentLoaded', async () => {
  // Get context from active tab
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab?.id) {
      const ctx = await chrome.tabs.sendMessage(tab.id, { type: 'GET_CONTEXT' }).catch(() => null);
      if (ctx) {
        pageContext = ctx;
        setDetectedPlatform(ctx.platformName, ctx.platform);
        if (ctx.lastAIMessage) {
          lastSnippet = ctx.lastAIMessage;
          const snippetEl = document.getElementById('ai-snippet');
          snippetEl.textContent = lastSnippet;
          document.getElementById('snippet-wrap').style.display = 'block';
        }
      }
    }
  } catch(e) {}

  // Restore saved mode
  const saved = await chrome.storage.local.get('lastMode').catch(() => ({}));
  if (saved?.lastMode) setMode(saved.lastMode, true);
});

function setDetectedPlatform(name, value) {
  document.getElementById('platform-badge').textContent = name;
  const sel = document.getElementById('f-platform');
  for (const opt of sel.options) {
    if (opt.value === value) { opt.selected = true; break; }
  }
}

function setMode(mode, skipSave) {
  currentMode = mode;
  document.getElementById('btn-fail').className = 'mode-btn' + (mode === 'fail' ? ' active-fail' : '');
  document.getElementById('btn-win').className  = 'mode-btn' + (mode === 'win'  ? ' active-win'  : '');
  document.getElementById('title-label').textContent = mode === 'fail' ? 'What went wrong?' : 'What did AI do well?';
  document.getElementById('desc-label').textContent  = mode === 'fail' ? 'Details (optional)' : 'Tell us more (optional)';
  document.getElementById('btn-submit').textContent  = mode === 'fail' ? 'Submit Fail →' : 'Submit Win ✦';
  document.getElementById('btn-submit').className = `btn-submit ${mode === 'fail' ? 'fail-mode' : 'win-mode'}`;
  document.getElementById('f-title').placeholder = mode === 'fail'
    ? 'e.g. ChatGPT forgot my context mid-session'
    : 'e.g. Claude solved a 2-hour problem in 30 seconds';
  if (!skipSave) chrome.storage.local.set({ lastMode: mode }).catch(() => {});
}

function useSnippet() {
  const desc = document.getElementById('f-desc');
  desc.value = lastSnippet.slice(0, 500);
  desc.focus();
}

async function submitIncident() {
  const title    = document.getElementById('f-title').value.trim();
  const platform = document.getElementById('f-platform').value;
  const desc     = document.getElementById('f-desc').value.trim();

  if (!title) {
    document.getElementById('f-title').focus();
    return;
  }

  const btn = document.getElementById('btn-submit');
  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span>Submitting…';

  const severity = currentMode === 'fail' ? 'medium' : 'positive';
  const payload = {
    title,
    description: desc || undefined,
    platform,
    severity,
    source: 'extension',
    url: pageContext?.url,
    tags: [currentMode === 'fail' ? 'ILLING' : 'CHILLING', 'extension', platform],
  };

  const res = await chrome.runtime.sendMessage({ type: 'SUBMIT_INCIDENT', payload });

  if (res?.ok) {
    showResult(true, res.data?.id || res.data?.incident_id || '');
  } else {
    // Fallback: try direct fetch (some MV3 configs allow it from popup)
    try {
      const r = await fetch('https://api.coreyai.ai/api/v1/submit', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      });
      const d = await r.json();
      showResult(true, d?.id || d?.incident_id || '');
    } catch(e) {
      showResult(false, '');
    }
  }
}

function showResult(ok, id) {
  document.getElementById('view-form').style.display = 'none';
  document.getElementById('view-result').style.display = 'block';
  document.getElementById('result-icon').textContent  = ok ? (currentMode === 'fail' ? '🔥' : '✦') : '⚠️';
  document.getElementById('result-msg').textContent   = ok
    ? (currentMode === 'fail' ? 'Fail logged. Keeping AI honest.' : 'Win logged. AI got it right.')
    : 'Connection failed. Check coreyai.ai to submit manually.';
  if (id) document.getElementById('result-id').textContent = 'ID: ' + id;
}

function reset() {
  document.getElementById('view-form').style.display = 'block';
  document.getElementById('view-result').style.display = 'none';
  document.getElementById('f-title').value = '';
  document.getElementById('f-desc').value  = '';
  document.getElementById('result-id').textContent = '';
  const btn = document.getElementById('btn-submit');
  btn.disabled = false;
  setMode(currentMode, true);
}
