// CoreyAI Content Script — detects AI platform, exposes helper for popup
(function() {
  const PLATFORMS = {
    'chat.openai.com': { name: 'ChatGPT', platform: 'chatgpt' },
    'chatgpt.com':     { name: 'ChatGPT', platform: 'chatgpt' },
    'claude.ai':       { name: 'Claude',  platform: 'claude' },
    'gemini.google.com': { name: 'Gemini', platform: 'gemini' },
    'copilot.microsoft.com': { name: 'Copilot', platform: 'copilot' },
    'perplexity.ai':   { name: 'Perplexity', platform: 'perplexity' },
    'grok.x.com':      { name: 'Grok', platform: 'grok' },
    'x.com':           { name: 'Grok', platform: 'grok' },
  };

  const host = window.location.hostname.replace('www.', '');
  const info = PLATFORMS[host] || { name: 'Unknown AI', platform: 'other' };

  // Try to grab last AI message from common selectors
  function getLastAIMessage() {
    const selectors = [
      // ChatGPT
      '[data-message-author-role="assistant"] .markdown',
      '[data-message-author-role="assistant"] p',
      // Claude
      '[data-is-streaming="false"] .font-claude-message',
      '.font-claude-message p',
      // Gemini
      'model-response .markdown',
      // Generic
      '.message.bot', '.assistant-message', '.ai-response',
    ];
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      if (els.length > 0) {
        const last = els[els.length - 1];
        const text = last.innerText?.trim();
        if (text && text.length > 10) return text.slice(0, 500);
      }
    }
    return '';
  }

  // Expose via message
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'GET_CONTEXT') {
      sendResponse({
        platform: info.platform,
        platformName: info.name,
        url: window.location.href,
        title: document.title,
        lastAIMessage: getLastAIMessage(),
      });
    }
  });
})();
