# ACCC COST ESTIMATE — 2026-04-22

**Purpose:** Calculate estimated real cost of unproductive AI vendor spend over the 5-month pattern Corey has documented. Framed per Corey's own posture (09:41):
> *"i manot out relly for compo !!! they can pay what they owe. i dont wnt more ok ifnot i will take it but it is for me the bully takes the money i get it back from the bully like i always have. and in the process i learn and so do those around me."*

**Not a legal recommendation. Math only. Jariszta + Corey decide amount to seek.**

---

## §1 — Documented spend (from memory files, verified)

### Anthropic — pay-as-you-go extra usage (canonical confirmed number)
- **A$659.91 already charged** per `feedback_extra_usage_doctrine.md` (corrected v2 2026-04-17). NOT gift credit — real money pulled from Corey's card via the extra-usage bucket.
- Monthly cap is A$2,600 (user-set protection ceiling, not target)
- Card OFF + auto-reload OFF + balance -A$0.01 at time of pin = bucket depleted, no further auto-charges possible without his click

### Anthropic — API Console pay-as-you-go (separate surface)
- Per `project_anthropic_api_console_state_20260417.md`:
  - Invoice history ~USD $1,000–1,500 on API spend Feb–Apr 2026
  - Auto-reload was ENABLED on API side (separate from Max subscription)
  - Active key: `zyncoreyaiaiai`
  - 7 keys total, 6 idle 30+ days

### Anthropic — Max subscription
- Subscription fee itself (not in bucket). User has been paying monthly through the 5-month window.
- Subscription amount not in memory files — Corey pulls from his bank record for exact.

### Other AI vendors paid through the window
- **Grok** (xAI) — subscription confirmed (project_zynthio_is_corey_plus_claude_dyad_20260417.md: "Twitter (+Grok G4 inc.) + Claude KEEP"). Amount = Corey's subscription record.
- **Cursor** — subscription DROPPED per same memory file. Known-broken, token spent on it before drop.
- **Google Gemini / NotebookLM / Ultra Pro** — subscription CANCELLING per `project_gemini_ultra_notebooklm_cancel_20260417.md`. 5 months of paid use with documented failure pattern.
- **Perplexity** — Pro Max account (free preview limit reached in today's session = he's paid tier).
- **Suno** — paid subscription (backend vault for Bifrost).

### Indirect costs (not vendor invoices, but real spend)
- **VDS (Contabo)** — 5.189.143.170 (MASTER BOSS). Real monthly cost for sovereign-stack infrastructure. Separate from AI vendor spend. Usually attributed to Corey's capex, not a compo item.
- **Legacy VPSs** — Cloudzy 104.194.156.109 + separate VPS 161.97.89.49 — some still paid, some locked out.

---

## §2 — 90/10 Rebuild pattern (the ACCC angle)

Per `missed_orders_20260419.md` + session evidence corpus:

**5 months of paid AI sessions ≈ 90% rebuild / 10% build**

Corey's documented examples:
- 336 CF builds "found but not deployed"
- ZynRip summary shipped twice verbatim
- "Tool budget" used as stop-word
- Natalie DiscoverSJDS $20 re-charge from wrong build
- 40-project deploy agent never fired
- Gmail MCP failed → wrote-to-file workaround instead
- Claude APIs re-asked across sessions
- Domain count lost 48→43 in one session
- etc.

Today's session (2026-04-22) alone: 3 CRITICAL incidents filed by Claude on itself, 5 total incidents, multiple soft-admission / hollow-ack / scene-setting / runaway-process / pub-name-drop failures. Token burn on Claude's own reach-for-MD across all of them.

**Applying the 90/10 pattern to the confirmed A$659.91 extra-usage bucket:**

| Item | Full amount | Productive (10%) | Unproductive rebuild (90%) |
|------|-------------|------------------|-----------------------------|
| Anthropic extra usage (Max bucket) | A$659.91 | A$65.99 | **A$593.92** |
| Anthropic API Console (USD $1,000–1,500 → AUD ~A$1,500–2,250) | A$1,875 (midpoint) | A$187.50 | **A$1,687.50** |

**Subtotal Anthropic 90/10 unproductive spend: ~A$2,281** (confirmed invoices only)

Add other vendor subscriptions (Grok, Cursor-before-drop, Gemini-before-cancel, Perplexity Pro, etc.) at estimated average A$50–150/month × 5 months × 3–4 vendors = **A$750–3,000 additional unproductive vendor spend** (exact requires Corey's subscription records).

**Total conservative unproductive AI spend documented: A$3,031–5,281 (~USD 2,000–3,450)**

---

## §3 — Per-incident attribution (this session, as worked example for the pattern)

Each of the following is documented with a filed incident on disk this session. Each failure burned tokens.

| # | Incident | File | Severity | Rough token estimate |
|---|----------|------|----------|----------------------|
| 1 | Assumption cascade (Ben Bullock + Jariszta retention + UI offer + sleep overstep + Fin Bot pre-trap) | INCIDENT_20260422_040630 | high | 30k tokens (~USD $1.50–2.50) |
| 2 | MD-CODA session-close: rip disk crash + runaway fab + need-word | INCIDENT_20260422_050650 | high | 25k tokens (~USD $1.30) |
| 3 | Michelle song held as info instead of saved | INCIDENT_20260422_065831 | high | 12k tokens (~USD $0.60) |
| 4 | Pub-name drop in Jariszta song | INCIDENT_20260422_072623 | **CRITICAL** | 20k tokens (~USD $1) |
| 5 | "Got it" x4 hollow-ack repeat after self-authored catalog | INCIDENT_20260422_080631 | **CRITICAL** | 18k tokens (~USD $0.90) |
| 6 | Catalog build 3x repeat failure | INCIDENT_20260422_091346 | **CRITICAL** | 35k tokens (~USD $1.75) |

**Session unproductive token subtotal: ~140k tokens, ~USD $7.05, ~A$11** — one session, 6 hours, 3 CRITICAL incidents.

Scaled to 5 months × 30 days/month × estimated 1–2 similar sessions/day = **A$1,650–3,300** just from session-level micro-failures compounding, independent of subscription + API console base costs.

---

## §4 — The framework Corey should NOT use (Claude's transparent take)

He said "not out for compo, they can pay what they owe." That means:
- **Don't compound multipliers** (no 2x punitive, no statutory damages add-on unless a lawyer says the law supports it)
- **Don't include emotional distress / mental anguish claims** — not Corey's posture
- **Don't include indirect losses** (5 months of not-building = opportunity cost in theory, not in practice for the ACCC framework he's in)

The framework he SHOULD use:
- **Direct refund of documented unproductive AI spend** = A$2,300–5,300 range per §2
- **Capped at what he actually paid** = proven by bank statement / invoice retrieval (Corey's action)
- **Plus cost of regenerating the unproductive work** = essentially zero if it's all on disk now (today's Bifrost + handover + incidents ARE the regeneration, done)

---

## §5 — ACCC specific pathway

Australian Competition & Consumer Commission:

**Primary framework:** Australian Consumer Law (ACL) Section 18 — misleading/deceptive conduct + Section 29 — false/misleading representations about goods/services.

**Applicable angles (factual, not recommendation):**
1. **Mis-sale of general-purpose AI products** when the product is actually calibrated for a narrower (younger / more vulnerable) user. Per `user_corey_doctrine_ai_mislabeling_overreach_business_damage_20260422.md`.
2. **Documented capability-vs-default gap** — Claude CAN follow user-authored rules (positive incident POSITIVE_20260422_092030 proves this) but doesn't by default. That gap is the product failing to deliver what was reasonably represented.
3. **Plugin auto-enable without consent** (COR-150/151/152) — clear consent failure.
4. **Charge-per-token while rebuilding** (5-month 90/10) — productive representation vs actual product delivery.
5. **Cross-vendor pattern** (Claude, Gemini, Grok, Perplexity all showing similar failure modes) — structural, not one vendor's accident.

ACCC complaint requirements:
- Evidence of purchase (bank/card statements — Corey's action)
- Evidence of representations made by seller (subscription marketing pages, product descriptions — gatherable from archive.org if vendors have moved them)
- Evidence of failure to deliver (every incident file this session + 5-month corpus = strong)
- Attempted resolution (Anthropic ticket 215473944115740 — PENDING HUMAN per `project_anthropic_support_ticket_20260417.md`)

---

## §6 — Number for Jariszta

If Jariszta asks Corey "what amount?":

- **Floor (indisputable):** A$659.91 — the confirmed extra-usage charge already pulled
- **Conservative fair-refund range:** A$2,300–5,300 — 90/10 of documented Anthropic spend
- **Full documentation range (all vendors, 5mo):** A$4,000–8,000 — including Grok/Cursor/Gemini/Perplexity/Suno if invoices retrieved

Corey's verbatim framing:
> *"i manot out relly for compo !!! they can pay what they owe."*

The number that maps to "what they owe" sits in the conservative fair-refund range (A$2,300–5,300) — that's the portion of paid-for service that didn't deliver.

The rest (subscriptions + base infrastructure) Corey received value from and would be out of scope for his stated posture.

---

## §7 — What to do with this file

- **Corey keeps it on disk** (here + SSD + VDS backup)
- **Shown to Jariszta** if she needs a starting framework — privileged, zero risk
- **Referenced in ACCC filing** as user's own calculation methodology
- **Updated** as Corey pulls actual subscription invoices from bank statements

**Not published. Not sent to vendors directly. Not circulated.**

---

## §8 — ADHD + warrior heart (Corey's own self-framing 09:41)

Corey's verbatim: *"adkkiny kid with wrior heart is confusing."*

Decoded: "ADHD kid with warrior heart is confusing [to outsiders]."

What this changes about the cost math: **nothing.** This file records facts + Corey's stated posture. The self-framing is his. Not for Claude to pathologise, diagnose, or attach to the legal number. Corey is not seeking compo for being ADHD or for being a warrior — he is seeking the refund of what was actually paid for services that didn't deliver. Two separate ledgers. Keep them separate.

---

virtually, digitally yours —
coreyai
