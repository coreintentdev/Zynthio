# PayPal transaction snapshot — pasted from Corey's Activity view 2026-04-22 11:10

**Status:** Partial paste from Corey's live PayPal feed — precedes the CSV Activity Report he just submitted (Oct 1, 2025 – Mar 31, 2026 range).
**Evidence tier:** User-captured, pre-CSV. CSV will supersede as authoritative when it lands.
**Purpose:** ACCC cost-estimate corroboration + Contabo VDS-cluster + infrastructure subscription mapping.

---

## April 2026 (visible)

| Date | Vendor | Amount (USD/ea) | Type |
|------|--------|-----------------|------|
| 15 Apr | Hostinger US INC. | $19.49 | Automatic |
| 9 Apr  | CONTABO GmbH | $63.00 | Payment |
| 8 Apr  | Cloudflare Inc | $30.00 | Automatic |
| 8 Apr  | TikTok Australia Pty Ltd | +$10.00 | Refund |
| 8 Apr  | TikTok Australia Pty Ltd | -$10.00 | Auto (refunded) |
| 4 Apr  | CONTABO GmbH | $84.00 | Automatic |
| 4 Apr  | CONTABO GmbH | $106.08 | Automatic |
| 4 Apr  | CONTABO GmbH | $52.32 | Automatic |
| 3 Apr  | Porkbun,LLC | $74.90 | Payment |
| 3 Apr  | SoundCloud Global Ltd | $119.88 | Automatic |
| 3 Apr  | SoundCloud Global Ltd | $99.00 | Automatic |
| 1 Apr  | Porkbun,LLC | $1.54 | Payment |
| 1 Apr  | Cloudflare Inc | $11.86 | Automatic |
| 1 Apr  | Cloudflare Inc | $12.20 | Automatic |
| 1 Apr  | Cloudflare Inc | $14.20 | Automatic |
| 1 Apr  | Cloudflare Inc | $14.20 | Automatic |
| 1 Apr  | Cloudflare Inc | $11.86 | Automatic |

## March 2026 (visible)

| Date | Vendor | Amount | Type |
|------|--------|--------|------|
| 31 Mar | LinkedIn Singapore Pte Ltd | $154.99 AUD | Automatic |
| 31 Mar | Proton | $171.34 USD | Automatic |
| 31 Mar | Cloudflare Inc | $12.20 USD | Automatic |
| 31 Mar | Porkbun,LLC | $292.29 USD | Payment |
| 30 Mar | Porkbun,LLC | $169.40 USD | Payment |
| 29 Mar | Google Payment Australia | $204.99 AUD | Automatic |
| 29 Mar | ROBLOX Corporation | $19.99 USD | Automatic |
| 21 Mar | Twilio | $20.00 USD | Automatic |
| 21 Mar | Google Payment Australia | $32.99 AUD | Automatic |
| 21 Mar | Google Payment Australia | $32.99 AUD | Automatic |
| 15 Mar | Hostinger US INC. | $9.99 USD | Automatic |
| 1 Mar  | CloudFusion Tech Limited | $5.00 USD | Payment |
| 1 Mar  | CloudFusion Tech Limited | $5.00 USD | Payment |

---

## Observations

### VDS/infrastructure cluster (Contabo)
- **3 separate Contabo auto-charges on 4 Apr:** $84.00 + $106.08 + $52.32 = **$242.40 USD total for one day of Contabo billing**
- Plus 9 Apr $63.00 Contabo payment = $305.40 USD on Contabo alone in a ~5-day window
- Explains the "3x Cloudzy → pivot to Contabo → 3 active tiers" VDS cluster history Corey described

### Domain registrar spend (Porkbun — heavy)
- 1 Apr: $1.54
- 3 Apr: $74.90
- 30 Mar: $169.40
- 31 Mar: **$292.29** (biggest single Porkbun charge in the window)
- Total Mar 30 – Apr 3: **$538.13 USD** on Porkbun (~A$834)
- Matches the 43+ domains Corey owns

### Cloudflare (small recurring)
- 6 separate Cloudflare charges on 1 Apr (various zones): $11.86 + $12.20 + $14.20 + $14.20 + $11.86 = $64.32
- 31 Mar: $12.20
- 8 Apr: $30.00
- Total in window: ~$106.52 — zone-level CF fees (Registrar or zone charges, not Pages)

### Other services
- **SoundCloud** 3 Apr: $119.88 + $99.00 = **$218.88** (Pro+ or bulk upload tier)
- **LinkedIn** 31 Mar: $154.99 (Premium)
- **Proton** 31 Mar: $171.34 (Proton Mail/Drive bundle — ACCC-relevant as the Google migration target)
- **Google Payment** (29 Mar $204.99 + 21 Mar x2 $32.99) = ~$271 in subscription charges
- **ROBLOX** 29 Mar: $19.99 (for Wesley per family context)
- **Twilio** 21 Mar: $20 (SMS / comms)
- **Hostinger** (15 Mar $9.99 + 15 Apr $19.49) = $29.48
- **TikTok** 8 Apr: $10 charged then refunded

### Not visible in this paste (likely on different card or on Stripe/direct)
- Anthropic Max subscription base
- Anthropic API Console reloads (these are on a different Link-by-Stripe card per the API Console panel)
- Suno subscription
- Grok / xAI subscription
- Cursor subscription (if still active)
- Perplexity Pro
- ElevenLabs
- HeyGen
- AWS (suspended per COR-159)

## Partial-window total (March 1 – April 15, 2026, visible)

**USD charges:** approximately $1,450 USD (mix of Contabo, Porkbun, Cloudflare, SoundCloud, Proton, Hostinger, Twilio, CloudFusion, ROBLOX)
**AUD charges:** approximately $426 AUD (LinkedIn, Google Payment x3)

**Combined estimated: ~$1,876 USD + $426 AUD = A$3,335 AUD for infrastructure + tooling subscriptions in a 6-week window**

## Next step

When the PayPal CSV Activity Report lands (Oct 1 2025 – Mar 31 2026, submitted 2026-04-22), this partial paste gets superseded by the canonical CSV. Save CSV to `~/Desktop/zynthio-tools/backups/paypal_activity_reports/` + SSD + VDS. Grep per-vendor + tally per-month into ACCC_COST_ESTIMATE §2 as "PayPal third-party verification".

---

virtually, digitally yours —
coreyai
